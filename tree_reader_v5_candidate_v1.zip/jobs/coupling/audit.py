from pathlib import Path
from fractions import Fraction as Q
import json,hashlib
ROOT=Path(__file__).resolve().parent

class Metric:
    def __init__(self,g):
        self.C=g['C'];self.par={v:p for p,v,w in g['edges']};self.w={v:Q(w) for p,v,w in g['edges']}
        self.ch={v:[] for v in [0,*self.par]};self.chain={0:[0]};self.anc={0:set()};self.height={0:Q(0)};self.cache={}
        for p,v,w in g['edges']:self.ch[p].append(v)
        for v in self.par:
            path=[v]
            while path[-1]:path.append(self.par[path[-1]])
            self.chain[v]=path;self.anc[v]=set(path[:-1]);self.height[v]=sum(self.w[e] for e in path[:-1])
        self.B=2*sum(self.w.values())
    def path(self,u,v):
        p,q=self.chain[u],self.chain[v];s=set(q);meet=next(z for z in p if z in s)
        return p[:p.index(meet)]+q[:q.index(meet)+1][::-1]
    def dist(self,u,v):
        key=(u,v)
        if key not in self.cache:
            p=self.path(u,v);self.cache[key]=sum(self.w[b if self.par.get(b)==a else a] for a,b in zip(p,p[1:]))
        return self.cache[key]

def main():
    spec=json.loads((ROOT/'SPEC.json').read_text());source=json.loads((ROOT/'SOURCE.json').read_text());cases={c['id']:c for c in spec['cases']}
    oldpath=Path(source['reference_remote_rows']);assert hashlib.sha256(oldpath.read_bytes()).hexdigest()==source['reference_rows_sha256']
    terminal=Path(source['reference_remote_terminal']);assert hashlib.sha256(terminal.read_bytes()).hexdigest()==source['reference_terminal_sha256']
    assert json.loads(terminal.read_text())['state']=='complete'
    metrics={g['id']:Metric(g) for g in spec['graphs']};snapshots=0;gaps=[];maxgap=Q(0);oldrows=newrows=oldsegments=newsegments=0
    def replay(row,gid,a,D,order,scout_order,tag):
        nonlocal snapshots,maxgap
        m=metrics[gid];C=m.C;pos={c for i,c in enumerate(C) if D>>i&1};first={};clock=Q(0);previous=0;drone=[]
        for goal in [*scout_order,0]:
            p=m.path(previous,goal)
            for u,v in zip(p,p[1:]):
                e=v if m.par.get(v)==u else u;end=clock+m.w[e]/a;drone.append([str(clock),str(end),u,v]);clock=end
                if v in C:first.setdefault(v,clock)
            previous=goal
        assert row['drone']==drone and Q(row['S'])==clock==m.B/a
        assert row['first']==row['release']=={str(c):str(first[c]) for c in C}
        bits={c:1<<i for i,c in enumerate(order)};eligible=(1<<len(order))-1;agenda=sorted((first[c],c) for c in C)
        ri=0;t=Q(0);node=0;edge=None;x=None;known={};served=set()
        def update():
            nonlocal ri,eligible
            while ri<len(agenda) and agenda[ri][0]<=t:
                at,v=agenda[ri];assert at==t;known[v]=v in pos
                if v not in pos:eligible&=~bits[v]
                ri+=1
            if node in bits:
                known[node]=node in pos;eligible&=~bits[node]
                if node in pos:served.add(node)
        for s in row['segments']:
            t0,t1,e,x0,x1,goal=s;t0,t1,x0,x1=map(Q,[t0,t1,x0,x1]);assert t0==t and t1>t
            update();remaining=[v for v in order if eligible&bits[v]];assert goal==(remaining[0] if remaining else 0)
            if node is not None:
                p=m.path(node,goal);nxt=p[1];assert e==(nxt if m.par.get(nxt)==node else node)
                assert x0==(0 if m.par.get(nxt)==node else m.w[e]);rootdistance=m.height[node]
                need=set(z for v in remaining for z in m.anc[v])|m.anc[node];weight=sum((m.w[z] for z in need),Q(0))
                pd=lambda v:m.dist(node,v)
            else:
                assert e==edge and x0==x
                need=set(z for v in remaining for z in m.anc[v])|m.anc[m.par[e]]
                weight=sum((m.w[z] for z in need),Q(0))+(x0 if e not in need else 0)
                rootdistance=m.height[m.par[e]]+x0
                pd=lambda v:min(x0+m.dist(m.par[e],v),m.w[e]-x0+m.dist(e,v))
            optimal=2*weight-rootdistance
            chain=(pd(remaining[0])+sum((m.dist(u,v) for u,v in zip(remaining,remaining[1:])),Q(0))+m.dist(remaining[-1],0)) if remaining else rootdistance
            gap=chain-optimal;assert gap>=0;maxgap=max(maxgap,gap);snapshots+=1
            if gap and len(gaps)<20:gaps.append({'id':tag,'time':str(t),'remaining':remaining,'chain':str(chain),'optimal':str(optimal)})
            direction=1 if e in m.anc[goal] else -1;arrival=t+(m.w[e]-x0 if direction>0 else x0)
            report=agenda[ri][0] if ri<len(agenda) else arrival
            assert t1==min(arrival,report) and x1==x0+direction*(t1-t0) and 0<=x1<=m.w[e]
            t=t1;node=None;edge=e;x=x1
            if t1==arrival:node=e if x1==m.w[e] else m.par[e];edge=x=None
        update();assert node==0 and not eligible and served==pos and set(known)==set(C)
        assert row['served']==row['actual']==sorted(pos) and not row['target_events']
        assert Q(row['T'])==t and Q(row['H'])==max(t,clock)<=m.B
        return len(row['segments'])+len(row['drone'])
    for raw in oldpath.open():
        row=json.loads(raw)
        if row['variant']!='all_immediate':continue
        oldsegments+=replay(row,row['graph'],Q(row['a']),row['D'],row['order'],row['order'],'old_'+str(oldrows));oldrows+=1
    pairs={};offsegments=0
    with (ROOT/'OFFLINE_WITNESSES.jsonl').open('x') as witnesses:
        for raw in (ROOT/'ROWS.jsonl').open():
            row=json.loads(raw);case=cases[row['id']];m=metrics[case['graph']];a=Q(case['a'])
            newsegments+=replay(row,case['graph'],a,case['D'],case['order'],case['scout_order'],row['id']);newrows+=1
            assignments={'car':[case['positive']],'scout':[v for v in m.C if v!=case['positive']]};times={};plans={}
            for label,targets in assignments.items():
                need=set(e for v in targets for e in m.anc[v]);speed=1 if label=='car' else a;tt=Q(0);trace=[]
                def visit(v):
                    nonlocal tt
                    for child in m.ch[v]:
                        if child not in need:continue
                        end=tt+m.w[child]/speed;trace.append([str(tt),str(end),v,child]);tt=end;visit(child)
                        end=tt+m.w[child]/speed;trace.append([str(tt),str(end),child,v]);tt=end
                visit(0);times[label]=tt;plans[label]=trace;offsegments+=len(trace)
            assert times=={'car':Q(1),'scout':Q(1)} and 2*m.height[case['positive']]==1
            witnesses.write(json.dumps({'id':row['id'],'plans':plans,'matching_lower_bound':'1'},separators=(',',':'))+'\n')
            pairs.setdefault((case['a'],case['n'],case['coupling']),[]).append(Q(row['H']))
    assert oldrows==4080 and newrows==40
    summary=[]
    for (astr,n,coupling),hs in pairs.items():
        assert len(hs)==2;summary.append({'a':astr,'n':n,'coupling':coupling,'mean_ratio':str(sum(hs)/2)})
    result=json.loads((ROOT/'RESULT.json').read_text());assert summary==result['summary']
    predicted=next(Q(s['mean_ratio']) for s in summary if (s['a'],s['n'],s['coupling'])==('2',8,'opposite'))
    report={'state':'snapshot_replan_and_coupling_audit_complete','old_rows_read_only':oldrows,'new_complete_rows':newrows,
            'old_physical_segments_rechecked':oldsegments,'new_physical_segments':newsegments,'offline_witness_segments':offsegments,
            'snapshot_states':snapshots,'max_snapshot_gap':str(maxgap),'snapshot_gap_witnesses':gaps,
            'a2_n8_opposite_mean':str(predicted),'a2_n8_lower_bound':'149/72','analytic_prediction_holds':predicted>=Q(149,72),
            'aligned_pair_violations':sum(Q(s['mean_ratio'])>2 for s in summary if s['coupling']=='aligned'),
            'summary':summary,'imports_engine_or_worker':False,'new_algorithm_necessity_claimed':False}
    (ROOT/'AUDIT_RESULT.json').open('x').write(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['summary','snapshot_gap_witnesses']}))
if __name__=='__main__':main()
