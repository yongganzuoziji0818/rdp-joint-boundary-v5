from pathlib import Path
from fractions import Fraction as Q
import json
from event_engine import run
ROOT=Path(__file__).resolve().parent
def main():
    spec=json.loads((ROOT/'SPEC.json').read_text());graphs={g['id']:g for g in spec['graphs']};pairs={};count=0
    with (ROOT/'ROWS.jsonl').open('x') as output:
        for case in spec['cases']:
            a=Q(case['a']);row=run(graphs[case['graph']],case['order'],a,case['D'],case['scout_order'])
            assert Q(row['H'])<=a+1
            output.write(json.dumps({'id':case['id'],**row},separators=(',',':'))+'\n')
            pairs.setdefault((case['a'],case['n'],case['coupling']),[]).append(Q(row['H']));count+=1
    summary=[]
    for (a,n,coupling),values in pairs.items():
        assert len(values)==2
        summary.append({'a':a,'n':n,'coupling':coupling,'mean_ratio':str(sum(values)/2)})
    assert count==40
    (ROOT/'RESULT.json').open('x').write(json.dumps({'state':'snapshot_coupling_trajectories_complete','rows':count,'summary':summary},indent=2))
if __name__=='__main__':main()
