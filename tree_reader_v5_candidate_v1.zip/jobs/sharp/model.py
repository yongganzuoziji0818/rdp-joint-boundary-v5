"""Original-tree physical controller with virtual candidate-event order."""
from fractions import Fraction as Q


class Tree:
    def __init__(self,g):
        self.C=tuple(g['C']);self.parent={};self.w={};self.ch={0:[]}
        for p,c,w in g['edges']:
            assert c not in self.parent and Q(w)>0
            self.parent[c]=p;self.w[c]=Q(w);self.ch.setdefault(p,[]).append(c);self.ch[c]=[]
        self.B=2*sum(self.w.values());self.paths={}
        for c in [0,*self.parent]:
            x=c;p=[]
            while x:p.append(x);x=self.parent[x]
            self.paths[c]=set(p)

    def route(self,u,v):
        aa=[u];bb=[v]
        while aa[-1]:aa.append(self.parent[aa[-1]])
        while bb[-1]:bb.append(self.parent[bb[-1]])
        while len(aa)>1 and len(bb)>1 and aa[-2]==bb[-2]:aa.pop();bb.pop()
        return aa+bb[-2::-1]

    def closed(self,C):return 2*sum((self.w[e] for e in set().union(*(self.paths[j] for j in C))),Q(0)) if C else Q(0)

    def offline(self,a,D):
        return min(max(self.closed([c for i,c in enumerate(self.C) if m>>i&1]),
                       self.closed([c for i,c in enumerate(self.C) if not m>>i&1])/a)
                   for m in range(1<<len(self.C)) if not D&~m)

    def run(self,o,a,D,variant="marker"):
        pos={c for i,c in enumerate(self.C) if D>>i&1};release={};first={0:Q(0)};dt=Q(0);prev=0
        drone=[]
        for goal in [*o,0]:
            rr=self.route(prev,goal)
            for u,v in zip(rr,rr[1:]):
                e=v if self.parent.get(v)==u else u;end=dt+self.w[e]/a
                drone.append([str(dt),str(end),u,v]);dt=end;first.setdefault(v,dt)
            if goal:release[goal]=dt
            prev=goal
        assert dt==self.B/a and set(release)==set(self.C)
        assert variant in ["marker","scout_immediate","all_immediate"]
        if variant!="marker":release={j:first[j] for j in self.C}
        agenda=sorted((stamp,j) for j,stamp in release.items());ri=0;t=Q(0);node=0;e=None;x=None
        known={};served=set();actual=set();segments=[];zero=[]
        for _ in range(2000):
            while ri<len(agenda) and agenda[ri][0]<=t:
                stamp,j=agenda[ri];assert stamp==t;known[j]=j in pos;ri+=1
            if node in pos:actual.add(node)
            if variant=="all_immediate" and node in self.C:
                known[node]=node in pos
                if node in pos:served.add(node)
            target=next((j for j in o if j not in served and known.get(j) is not False),0)
            if target and node==target:
                known[target]=target in pos
                if target in pos:served.add(target)
                zero.append([str(t),target,target in pos]);continue
            if target==0 and node==0:break
            if node is not None:
                nxt=self.route(node,target)[1]
                if self.parent.get(nxt)==node:e=nxt;x=Q(0);direction=1
                else:e=node;x=self.w[e];direction=-1
                node=None
            else:direction=1 if e in self.paths[target] else -1
            distance=self.w[e]-x if direction==1 else x;assert distance>0
            arrival=t+distance;report=agenda[ri][0] if ri<len(agenda) else arrival;end=min(arrival,report);assert end>t
            y=x+direction*(end-t)
            segments.append([str(t),str(end),e,str(x),str(y),target]);t=end;x=y
            if end==arrival:node=e if x==self.w[e] else self.parent[e];e=x=None
        else:raise AssertionError('finite event bound')
        assert served==pos and actual==pos and len(known)==len(self.C)
        return {'T':str(t),'S':str(dt),'H':str(max(t,dt)),'segments':segments,'target_events':zero,
                'release':{str(j):str(v) for j,v in release.items()},'first':{str(j):str(first[j]) for j in self.C},'drone':drone,
                'served':sorted(served),'actual':sorted(actual)}
