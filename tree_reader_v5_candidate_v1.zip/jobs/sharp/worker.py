from pathlib import Path
from fractions import Fraction as Q
import json
from model import Tree
R=Path(__file__).resolve().parent


def slow_run(tree,order):
    t=Q(0);prev=0;trace=[]
    for target in [*order,0]:
        rr=tree.route(prev,target)
        for u,v in zip(rr,rr[1:]):
            e=v if tree.parent.get(v)==u else u;end=t+tree.w[e];trace.append([str(t),str(end),u,v]);t=end
        prev=target
    return {'T':str(t),'S':'0','H':str(t),'truck_trace':trace,'drone':[],'served':[],'actual':[]}


def main():
    spec=json.loads((R/'SPEC.json').read_text());rows=0;groups={};modes={}
    with (R/'ROWS.jsonl').open('x') as out:
        for case in spec['cases']:
            g=case['graph'];tree=Tree(g);a=Q(case['a']);mode=case['mode'];D=case['D'];order=case['order']
            if mode=='slow':run=slow_run(tree,order)
            else:run=tree.run(order,a,D,'all_immediate')
            T,S,H=map(Q,[run['T'],run['S'],run['H']])
            card=tree.closed(case['offline_card']);drone=tree.closed(case['offline_drone'])/a;L=max(card,drone)
            assert set(case['offline_card'])|set(case['offline_drone'])==set(g['C'])
            if mode=='fast':
                n=case['n'];r=(a-1)/(2*n);expected=2-(a-1)/(a*n)
                assert tree.B==a+1 and card==drone==L==1 and tree.closed([1,3])==1
                assert T==H==expected and S==1+1/a and T-S==(a-1)/a*(1-Q(1,n))
            elif mode=='unit':assert tree.B==2 and card==drone==L==1 and T==S==H==2
            elif mode=='slow':assert tree.B==1+a and card==drone==L==1 and H==1+a and S==0
            elif mode=='budget':assert card==L==tree.B and drone==0 and H==tree.B
            else:raise AssertionError(mode)
            row={'id':case['id'],'graph':g['id'],'mode':mode,'a':str(a),'n':case.get('n'),'D':D,'order':order,'B':str(tree.B),'OPT':str(L),
                 'offline_card_time':str(card),'offline_drone_time':str(drone),**run}
            out.write(json.dumps(row,separators=(',',':'))+'\n');rows+=1;modes[mode]=modes.get(mode,0)+1
            if mode=='fast':groups.setdefault((str(a),case['n']),[]).append(H)
    for (a,n),values in groups.items():assert len(values)==2 and values[0]==values[1]
    assert rows==91 and len(groups)==42
    (R/'RESULT.json').open('x').write(json.dumps({'state':'fixed_speed_matching_family_screen_pass','rows':rows,'modes':modes,'fast_groups':42,
        'all_graphs_or_parameters_proved_by_test':False,'all_policy_lower_bound':False,'exponential_world_enumerations':0},indent=2))


if __name__=='__main__':main()
