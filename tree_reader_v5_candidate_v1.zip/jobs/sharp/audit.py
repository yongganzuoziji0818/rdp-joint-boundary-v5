"""Independent node paths, physical policy constraints and explicit offline witnesses."""
from pathlib import Path
from fractions import Fraction as Q
import json
R=Path(__file__).resolve().parent


def main():
    spec=json.loads((R/'SPEC.json').read_text());cases={c['id']:c for c in spec['cases']};seen=set();modes={};segments=offsegments=0;fastpairs={}
    with (R/'OFFLINE_PLANS.jsonl').open('x') as off:
        for raw in (R/'ROWS.jsonl').open():
            row=json.loads(raw);case=cases[row['id']];assert row['id'] not in seen;seen.add(row['id'])
            g=case['graph'];C=g['C'];a=Q(case['a']);mode=case['mode'];o=case['order'];D=case['D'];pos={c for i,c in enumerate(C) if D>>i&1}
            par={c:p for p,c,v in g['edges']};w={c:Q(v) for p,c,v in g['edges']};adj={v:{} for v in [0,*C]};ch={v:[] for v in adj}
            for u,v,z in g['edges']:adj[u][v]=adj[v][u]=Q(z);ch[u].append(v)
            paths={}
            for start in adj:
                queue=[[start]]
                for p in queue:
                    paths[start,p[-1]]=p;queue.extend(p+[c] for c in adj[p[-1]] if c not in p)
            anc={v:set(paths[0,v][1:]) for v in adj};B=2*sum(w.values());P=2*sum((w[e] for e in set(e for c in pos for e in anc[c])),Q(0))
            assert row['graph']==g['id'] and row['D']==D and row['order']==o and Q(row['B'])==B
            # Build actual offline closed subtree tours, not just a nominal numeric bound.
            plans={};times={}
            for name,assignment,speed in [('card',case['offline_card'],Q(1)),('drone',case['offline_drone'],a)]:
                need=set(e for c in assignment for e in anc[c]);clock=Q(0);trace=[]
                def dfs(v):
                    nonlocal clock,offsegments
                    for c in ch[v]:
                        if c not in need:continue
                        end=clock+w[c]/speed;trace.append([str(clock),str(end),v,c]);clock=end;offsegments+=1
                        dfs(c);end=clock+w[c]/speed;trace.append([str(clock),str(end),c,v]);clock=end;offsegments+=1
                dfs(0);plans[name]=trace;times[name]=clock
            assert set(case['offline_card'])|set(case['offline_drone'])==set(C) and pos<=set(case['offline_card'])
            L=max(times.values());assert Q(row['OPT'])==L and Q(row['offline_card_time'])==times['card'] and Q(row['offline_drone_time'])==times['drone']
            if mode in ['slow','unit']:lower=B/(a+1);reason='tree cut coverage plus combined speeds'
            else:lower=P;reason='mandatory positive-subtree closed truck travel'
            assert lower==L
            off.write(json.dumps({'id':row['id'],'plans':plans,'lower_bound':str(lower),'lower_reason':reason},separators=(',',':'))+'\n')
            T,S,H=map(Q,[row['T'],row['S'],row['H']]);assert H==max(T,S)<=B
            if mode=='slow':
                assert not row['drone'] and S==0 and not pos
                clock=Q(0);previous=0;expected=[]
                for target in [*o,0]:
                    rr=paths[previous,target]
                    for u,v in zip(rr,rr[1:]):
                        end=clock+adj[u][v];expected.append([str(clock),str(end),u,v]);clock=end
                    previous=target
                assert row['truck_trace']==expected and T==clock==B==1+a and L==1
                segments+=len(expected)
            else:
                # Rebuild the fixed physical scout tour and first observations.
                clock=Q(0);previous=0;first={0:Q(0)};expected=[]
                for target in [*o,0]:
                    rr=paths[previous,target]
                    for u,v in zip(rr,rr[1:]):
                        end=clock+adj[u][v]/a;expected.append([str(clock),str(end),u,v]);clock=end;first.setdefault(v,clock)
                    previous=target
                assert row['drone']==expected and S==clock==B/a
                assert {int(k):Q(v) for k,v in row['first'].items()}=={c:first[c] for c in C}
                assert row['release']==row['first']
                agenda=sorted((first[c],c) for c in C);ri=0;t=Q(0);node=0;edge=None;x=None;known={};served=set()
                def update():
                    nonlocal ri
                    while ri<len(agenda) and agenda[ri][0]<=t:
                        stamp,c=agenda[ri];assert stamp==t;known[c]=c in pos;ri+=1
                    if node in C:
                        known[node]=node in pos
                        if node in pos:served.add(node)
                def target():return next((c for c in o if c not in served and known.get(c) is not False),0)
                assert row['target_events']==[]
                for s in row['segments']:
                    t0,t1,e,x0,x1,goal=s;t0,t1,x0,x1=map(Q,[t0,t1,x0,x1]);assert t0==t and t1>t
                    update();assert goal==target()
                    if node is not None:
                        nv=paths[node,goal][1];assert e==(nv if par.get(nv)==node else node) and x0==(0 if par.get(nv)==node else w[e])
                    else:assert e==edge and x0==x
                    direction=1 if e in anc[goal] else -1;arrival=t+(w[e]-x0 if direction>0 else x0)
                    assert x1==x0+direction*(t1-t0) and 0<=x1<=w[e]
                    report=agenda[ri][0] if ri<len(agenda) else arrival;assert t1==min(arrival,report)
                    t=t1;edge=e;x=x1;node=None
                    if x1 in [0,w[e]]:node=e if x1==w[e] else par[e];edge=x=None
                update();assert node==0 and target()==0 and served==pos==set(row['served'])==set(row['actual']) and set(known)==set(C) and T==t
                segments+=len(row['segments'])+len(row['drone'])
                if mode=='fast':
                    n=case['n'];r=(a-1)/(2*n);Rtime=max(first[c] for c in C if c>=4)
                    assert Rtime==1-r/a
                    negout=[s for s in row['segments'] if s[2] not in {1,3} and Q(s[4])>Q(s[3])]
                    assert negout and all(s[2]==2 for s in negout)
                    last=negout[-1];assert Q(last[1])==Rtime and Q(last[4])==Q(1,2)-r/a
                    assert T==2*Rtime==2-(a-1)/(a*n) and T>=S and L==1
                    fastpairs.setdefault((str(a),n),[]).append(H)
                elif mode=='unit':assert a==1 and T==S==H==2 and L==1
                elif mode=='budget':assert pos==set(C) and T==H==B==L
                else:raise AssertionError(mode)
            modes[mode]=modes.get(mode,0)+1
    assert len(seen)==91 and len(fastpairs)==42
    for key,hs in fastpairs.items():assert len(hs)==2 and hs[0]==hs[1]
    result=json.loads((R/'RESULT.json').read_text());assert result['rows']==91 and result['modes']==modes
    (R/'AUDIT_RESULT.json').open('x').write(json.dumps({'state':'independent_fixed_speed_physical_and_optimality_witness_audit_pass','rows':91,'fast_groups':42,'modes':modes,
        'online_segments':segments,'offline_witness_segments':offsegments,'explicit_matching_offline_lower_bounds':91,'exponential_world_enumerations':0,
        'imports_controller_or_worker':False,'all_policy_lower_bound':False,'universal_proof_machine_formalized':False},indent=2))


if __name__=='__main__':main()
