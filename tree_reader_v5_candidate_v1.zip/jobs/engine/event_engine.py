"""Fixed tree policy, Euler membership and monotone goal pointer; exact event times."""
from fractions import Fraction as Q

def run(graph,order,a,D):
    assert a>=1
    C=graph['C'];cs=set(C);positive={v for i,v in enumerate(C) if D>>i&1}
    parent={0:0};length={};children={0:[]}
    for p,v,w in graph['edges']:
        assert v not in parent and Q(w)>0
        parent[v]=p;length[v]=Q(w);children.setdefault(p,[]).append(v);children.setdefault(v,[])
    depth={0:0};tin={};tout={};counter=0;stack=[(0,False)]
    while stack:
        v,exit=stack.pop()
        if exit:tout[v]=counter;continue
        tin[v]=counter;counter+=1;stack.append((v,True))
        for z in reversed(children[v]):depth[z]=depth[v]+1;stack.append((z,False))
    assert counter==len(parent) and set(order)==cs
    up=[parent.copy()]
    for _ in range(max(depth.values()).bit_length()):up.append({v:up[-1][up[-1][v]] for v in parent})
    inside=lambda e,v:tin[e]<=tin[v]<tout[e]
    def lift(v,d):
        b=0
        while d:
            if d&1:v=up[b][v]
            d>>=1;b+=1
        return v
    def path(u,v):
        left=[];right=[]
        while depth[u]>depth[v]:left.append(u);u=parent[u]
        while depth[v]>depth[u]:right.append(v);v=parent[v]
        while u!=v:left.append(u);right.append(v);u=parent[u];v=parent[v]
        return left+[u]+right[::-1]
    first={};drone=[];stamp=Q(0);last=0
    for goal in [*order,0]:
        pp=path(last,goal)
        for u,v in zip(pp,pp[1:]):
            e=v if parent[v]==u else u;end=stamp+length[e]/a
            drone.append([str(stamp),str(end),u,v]);stamp=end
            if v in cs:first.setdefault(v,stamp)
        last=goal
    B=2*sum(length.values());assert stamp==B/a and set(first)==cs
    agenda=sorted((value,key) for key,value in first.items());ri=0;t=Q(0);node=0;e=None;x=None
    active={v:True for v in C};known={};served=set();pointer=0;segments=[];arrivals=queries=0
    while True:
        while ri<len(agenda) and agenda[ri][0]<=t:
            at,v=agenda[ri];assert at==t;known[v]=v in positive
            if v not in positive:active[v]=False
            ri+=1
        if node in cs:
            known[node]=node in positive
            if node in positive:served.add(node)
            active[node]=False
        while pointer<len(order) and not active[order[pointer]]:pointer+=1
        target=order[pointer] if pointer<len(order) else 0
        if node==0 and target==0:break
        if node is not None:
            if inside(node,target):
                nxt=lift(target,depth[target]-depth[node]-1);queries+=1
                e=nxt;x=Q(0);direction=1
            else:e=node;x=length[e];direction=-1
            node=None
        else:direction=1 if inside(e,target) else -1
        arrival=t+(length[e]-x if direction>0 else x)
        report=agenda[ri][0] if ri<len(agenda) else arrival;end=min(arrival,report);assert end>t
        y=x+direction*(end-t);segments.append([str(t),str(end),e,str(x),str(y),target]);t=end;x=y
        if end==arrival:node=e if x==length[e] else parent[e];e=x=None;arrivals+=1
    assert set(known)==cs and served==positive
    return {'T':str(t),'S':str(stamp),'H':str(max(t,stamp)),'segments':segments,'target_events':[],
            'release':{str(v):str(first[v]) for v in C},'first':{str(v):str(first[v]) for v in C},'drone':drone,
            'served':sorted(served),'actual':sorted(served),
            'event_counts':{'pointer_advances':pointer,'reports_processed':ri,'node_arrivals':arrivals,'child_queries':queries,'segments':len(segments)}}
