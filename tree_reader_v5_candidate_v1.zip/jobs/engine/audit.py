"""Closed physical replay with parent chains and an eligibility bitset, not the engine."""
from pathlib import Path
from fractions import Fraction as Q
import json
ROOT=Path(__file__).resolve().parent

def main():
    cases={c['id']:c for c in json.loads((ROOT/'SPEC.json').read_text())['cases']};seen=set();counts={'parity':0,'large':0,'segments':0,'offline_segments':0}
    scale=[]
    with (ROOT/'OFFLINE_WITNESSES.jsonl').open('x') as witness:
        for raw in (ROOT/'ROWS.jsonl').open():
            row=json.loads(raw);case=cases[row['id']];assert row['id'] not in seen;seen.add(row['id'])
            g=case['graph'];C=g['C'];o=case['order'];a=Q(case['a']);pos={c for i,c in enumerate(C) if case['D']>>i&1}
            par={c:p for p,c,w in g['edges']};w={c:Q(v) for p,c,v in g['edges']};ch={v:[] for v in [0,*par]}
            for p,c,z in g['edges']:ch[p].append(c)
            chains={0:[0]}
            for v in par:
                pp=[v]
                while pp[-1]:pp.append(par[pp[-1]])
                chains[v]=pp
            anc={v:set(pp[:-1]) for v,pp in chains.items()}
            def path(u,v):
                pu,pv=chains[u],chains[v];sv=set(pv);common=next(z for z in pu if z in sv)
                return pu[:pu.index(common)]+pv[:pv.index(common)+1][::-1]
            B=2*sum(w.values());need=set(e for c in pos for e in anc[c]);P=2*sum((w[e] for e in need),Q(0))
            first={};previous=0;clock=Q(0);drone=[]
            for goal in [*o,0]:
                pp=path(previous,goal)
                for u,v in zip(pp,pp[1:]):
                    e=v if par.get(v)==u else u;end=clock+w[e]/a;drone.append([str(clock),str(end),u,v]);clock=end
                    if v in C:first.setdefault(v,clock)
                previous=goal
            assert row['drone']==drone and Q(row['S'])==clock==B/a
            assert row['first']==row['release']=={str(c):str(first[c]) for c in C}
            agenda=sorted((first[c],c) for c in C);ri=0;t=Q(0);node=0;edge=None;x=None;known={};served=set()
            bit={c:1<<i for i,c in enumerate(o)};eligible=(1<<len(o))-1;arrivals=0;directions={}
            def update():
                nonlocal ri,eligible
                while ri<len(agenda) and agenda[ri][0]<=t:
                    stamp,v=agenda[ri];assert stamp==t;known[v]=v in pos
                    if v not in pos:eligible&=~bit[v]
                    ri+=1
                if node in bit:
                    known[node]=node in pos;eligible&=~bit[node]
                    if node in pos:served.add(node)
            for s in row['segments']:
                t0,t1,e,x0,x1,goal=s;t0,t1,x0,x1=map(Q,[t0,t1,x0,x1]);assert t0==t and t1>t
                update();expected=o[(eligible&-eligible).bit_length()-1] if eligible else 0
                assert goal==expected
                if node is not None:
                    nxt=path(node,goal)[1];assert e==(nxt if par.get(nxt)==node else node)
                    assert x0==(0 if par.get(nxt)==node else w[e])
                else:assert e==edge and x0==x
                direction=1 if e in anc[goal] else -1
                arrival=t+(w[e]-x0 if direction>0 else x0);report=agenda[ri][0] if ri<len(agenda) else arrival
                assert t1==min(arrival,report) and x1==x0+direction*(t1-t0) and 0<=x1<=w[e]
                if not directions.get(e) or directions[e][-1]!=direction:directions.setdefault(e,[]).append(direction)
                assert directions[e] in [[1],[1,-1]]
                t=t1;x=x1;edge=e;node=None
                if t1==arrival:node=e if x1==w[e] else par[e];edge=x=None;arrivals+=1
            update();assert node==0 and not eligible and served==pos and set(known)==set(C)
            assert row['served']==row['actual']==sorted(pos) and not row['target_events']
            assert Q(row['T'])==t and Q(row['H'])==max(t,clock)<=B
            assert Q(row['H'])<=(2*B+(a-1)*P)/(a+1)
            assert arrivals==row['event_counts']['node_arrivals']<=2*len(par)
            assert len(row['segments'])==row['event_counts']['segments']<=len(C)+2*len(par)
            counts['segments']+=len(row['segments'])+len(drone)
            if case['kind']=='parity':
                for key,value in case['reference'].items():assert row[key]==value,(row['id'],key)
                counts['parity']+=1
            else:
                n=case['n'];assert P==1 and B==a+1 and t==2-(a-1)/(a*n)>=clock
                assignments={'car':[1,3],'scout':[v for v in C if v not in [1,3]]};times={};plans={}
                for label,assigned in assignments.items():
                    required=set(e for v in assigned for e in anc[v]);speed=1 if label=='car' else a;tt=Q(0);trace=[]
                    def visit(v):
                        nonlocal tt
                        for child in ch[v]:
                            if child not in required:continue
                            end=tt+w[child]/speed;trace.append([str(tt),str(end),v,child]);tt=end;visit(child)
                            end=tt+w[child]/speed;trace.append([str(tt),str(end),child,v]);tt=end
                    visit(0);times[label]=tt;plans[label]=trace;counts['offline_segments']+=len(trace)
                assert times=={'car':Q(1),'scout':Q(1)} and set(assignments['car'])|set(assignments['scout'])==set(C)
                witness.write(json.dumps({'id':row['id'],'plans':plans,'matching_lower_bound':'1','reason':'positive subtree mandatory truck return'},separators=(',',':'))+'\n')
                scale.append({'id':row['id'],'a':str(a),'n':n,'candidates':len(C),'H':str(t),'OPT':'1',**row['event_counts']});counts['large']+=1
    assert len(seen)==4186 and counts['parity']==4168 and counts['large']==18
    result=json.loads((ROOT/'RESULT.json').read_text());assert result['parity_rows']==4168 and result['large_constructed_rows']==18
    report={'state':'independent_event_engine_causality_physics_and_scale_audit_pass',**counts,'max_candidates':2051,'scale_rows':scale,
            'imports_event_engine_or_worker':False,'new_algorithm_novelty':False,'formal_proof_by_finite_check':False}
    (ROOT/'AUDIT_RESULT.json').open('x').write(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='scale_rows'}))
if __name__=='__main__':main()
