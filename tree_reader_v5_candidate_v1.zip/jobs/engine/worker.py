from pathlib import Path
from fractions import Fraction as Q
import json
from event_engine import run

ROOT=Path(__file__).resolve().parent
FIELDS=['T','S','H','segments','target_events','release','first','drone','served','actual']
def main():
    spec=json.loads((ROOT/'SPEC.json').read_text());parity=large=0;largest=0
    with (ROOT/'ROWS.jsonl').open('x') as output:
        for case in spec['cases']:
            a=Q(case['a']);result=run(case['graph'],case['order'],a,case['D'])
            if case['kind']=='parity':
                assert all(result[k]==case['reference'][k] for k in FIELDS),case['id'];parity+=1
            else:
                n=case['n'];assert Q(result['H'])==Q(result['T'])==2-(a-1)/(a*n)
                assert Q(result['S'])==1+1/a;large+=1
            assert result['event_counts']['node_arrivals']<=2*len(case['graph']['edges'])
            assert result['event_counts']['segments']<=len(case['graph']['C'])+2*len(case['graph']['edges'])
            largest=max(largest,len(case['graph']['C']))
            output.write(json.dumps({'id':case['id'],'kind':case['kind'],**result},separators=(',',':'))+'\n')
    assert parity==4168 and large==18
    report={'state':'independent_event_engine_qualification_complete','parity_rows':parity,'large_constructed_rows':large,'max_candidates':largest,
            'speed_superiority_claimed':False,'new_algorithm_novelty_claimed':False}
    (ROOT/'RESULT.json').open('x').write(json.dumps(report,indent=2));print(json.dumps(report))
if __name__=='__main__':main()
