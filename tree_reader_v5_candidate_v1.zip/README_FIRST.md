# V5 tree checks, private reader-package candidate

Requires Python 3.10 or later and only the standard library. No installation, network, GPU or model weights are required.

From this directory run:

    python -B reproduce.py --verify-only
    python -B reproduce.py --out ./fresh_results

The first verifies every member SHA-256 without task execution. The second requires a nonexistent output directory and stops on any error. It runs three original frozen worker/auditor pairs and compares twelve scientific output files byte-for-byte, including full trajectories and offline witnesses. No timing fields are exempted.

Coverage: 91 fixed-speed matching tasks; 4,168 event-engine reference qualifications plus 18 larger fixed constructions; 40 coupling tasks. These 4,317 replays reuse existing inputs and are NOT new independent scientific samples. The coupling audit also reads the original 8,160-row immediate-information file, selecting 4,080 all_immediate records and checking 52,326 states jointly with the forty tasks. It does not rerun all 8,160 immediate-variant tasks. Original module code and SPEC bytes remain unchanged. Only runtime SOURCE.json points the unmodified coupling audit to the packaged read-only reference files instead of its historical server path.

This is a bounded implementation/reproducibility packet. It does not prove universal theorems, certify novelty, establish a runtime speedup, or validate real disaster operations. Prior failures and other exploratory studies remain in the original project records and are not relabeled by this replay. The general-network packet is separate.

This package is currently private. Redistribution licensing and a persistent public archive have not been assigned. Inclusion here does not grant rights to republish third-party materials. No publication or submission is performed by these commands.
