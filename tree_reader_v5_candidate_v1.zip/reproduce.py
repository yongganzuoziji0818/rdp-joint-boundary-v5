"""Portable reader entry point. Frozen science modules are copied byte-for-byte."""
from pathlib import Path
import argparse, hashlib, json, shutil, subprocess, sys
ROOT=Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def verify(root):
    manifest=json.loads((root/'ARTIFACT_INDEX.json').read_text(encoding='utf-8'))
    for name,h in manifest['files'].items():
        rel=Path(name)
        if rel.is_absolute() or '..' in rel.parts:raise ValueError('unsafe manifest path')
        if sha(root/rel)!=h:raise ValueError('SHA-256 mismatch: '+name)
    return manifest
def main():
    ap=argparse.ArgumentParser();g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--verify-only',action='store_true');g.add_argument('--out',type=Path)
    args=ap.parse_args();manifest=verify(ROOT)
    if args.verify_only:
        print(json.dumps({'state':'reader_payload_hashes_verified','files':len(manifest['files']),
                          'scientific_execution':False}));return
    output=args.out.resolve()
    if output.exists():raise FileExistsError('fresh output directory required')
    output.mkdir(parents=True,exist_ok=False);completed=[];checks=[]
    jobs=json.loads((ROOT/'JOBS.json').read_text(encoding='utf-8'))
    for job in jobs:
        name=job['id'];work=output/name
        shutil.copytree(ROOT/'jobs'/name,work)
        if name=='coupling':
            old=ROOT/'reference_inputs'
            (work/'SOURCE.json').write_text(json.dumps({
             'reference_remote_rows':str(old/'immediate_ROWS.jsonl'),
             'reference_rows_sha256':sha(old/'immediate_ROWS.jsonl'),
             'reference_remote_terminal':str(old/'immediate_TERMINAL.json'),
             'reference_terminal_sha256':sha(old/'immediate_TERMINAL.json')},indent=2)+'\n',encoding='utf-8')
        for stage in ('worker','audit'):
            with (work/(stage+'.stdout')).open('xb') as stdout,(work/(stage+'.stderr')).open('xb') as stderr:
                result=subprocess.run([sys.executable,'-B',str(work/(stage+'.py'))],cwd=work,
                    stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=job['timeout_seconds'])
            if result.returncode:raise RuntimeError(name+'/'+stage+' failed; see fresh logs; no retry')
        for filename in job['outputs']:
            actual=sha(work/filename);expected=sha(ROOT/'reference'/name/filename)
            if actual!=expected:raise ValueError('scientific output differs: '+name+'/'+filename)
            checks.append({'path':name+'/'+filename,'sha256':actual,'byte_identical':True})
        completed.append(name)
    report={'state':'all_three_frozen_tree_jobs_reproduced','completed':completed,
            'scientific_files_compared':checks,'replayed_trajectories':4317,
            'old_snapshot_rows_read_only':4080,'new_independent_samples':0,
            'timing_fields_excluded':[],'scientific_source_changes':0,
            'path_adaptation':'coupling SOURCE.json only; science modules unchanged'}
    (output/'REPLAY_RESULT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='scientific_files_compared'}))
if __name__=='__main__':main()
