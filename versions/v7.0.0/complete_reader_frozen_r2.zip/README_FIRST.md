# V7 revision 5: complete private reader candidate

Python 3.10 or later, standard library only. No network, installation, GPU or training.
From a fresh extraction run:

```
python -B reproduce_all.py --verify-only
python -B reproduce_all.py --out ./fresh_results
python -B audit_replay.py --out ./fresh_results
```

Existing output directories cause a stop rather than replacement. Preserve logs after an error.
The first command verifies hashes and recursive archive CRCs without scientific execution.
The second reproduces the unchanged earlier archive (10,191 existing execution records) and
the two-world scalar-bound illustration (8 existing records, 96 exact allocation rows).
The third independently compares the complete outputs under the original contracts.
Record counts are not independent statistical sample counts. None of these checks proves
universal theorems or certifies novelty, journal suitability or acceptance.

The old component archive is embedded byte-for-byte. Its original timing-field exclusions,
semantic comparisons and byte comparisons remain unchanged. The new illustration uses
exact byte comparisons of four scientific output files; no numerical tolerance is introduced.
Its scientific modules and frozen reference outputs are unchanged from the original run.

The illustration explains why the same coverage and service scalar bounds can give different
complete-task feasibility answers. Ordinary tiny exhaustive allocation resolves it; no new
solver or empirical rescue improvement is claimed.

This is a private, unpublished candidate. No new public-release permission or license is
assigned by this package. Retained third-party/older component notices remain in place.
The v5 Zenodo DOI does not contain this later V7 package.
