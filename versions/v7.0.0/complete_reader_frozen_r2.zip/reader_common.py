"""Single offline entry point for unchanged V5/V7 finite evidence components."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, io, json, os, subprocess, sys, zipfile
ROOT=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def safe_name(name):
    q=PurePosixPath(name)
    if q.is_absolute() or '..' in q.parts or '\\' in name or ':' in name:
        raise ValueError('Unsafe archive member '+name)
    return q
def check_zip(data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        if z.testzip() is not None: raise ValueError('CRC mismatch')
        names=z.namelist()
        if len(names)!=len(set(names)):raise ValueError('Duplicate member')
        for name in names:
            safe_name(name)
            if name.endswith('.zip'):check_zip(z.read(name))
def verify():
    manifest=json.loads((ROOT/'MANIFEST.json').read_text(encoding='utf-8'))
    for name,h in manifest.items():
        safe_name(name)
        if sha(ROOT/name)!=h:raise ValueError('SHA-256 mismatch '+name)
        if name.endswith('.zip'):check_zip((ROOT/name).read_bytes())
    return len(manifest)
def extract(path,dest):
    dest.mkdir(parents=True,exist_ok=False)
    with zipfile.ZipFile(path) as z:
        for info in z.infolist():
            q=safe_name(info.filename)
            if info.is_dir():continue
            p=dest/str(q);p.parent.mkdir(parents=True,exist_ok=True)
            with p.open('xb') as f:f.write(z.read(info))
def run(out,label,cwd,*args):
    log=out/'logs';log.mkdir(exist_ok=True)
    env=os.environ.copy()
    for k in ['PYTHONPATH','PYTHONHOME','LD_PRELOAD']:env.pop(k,None)
    env.update(PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',CUDA_VISIBLE_DEVICES='')
    p=subprocess.run([sys.executable,'-s','-B',*map(str,args)],cwd=cwd,env=env,capture_output=True,timeout=300)
    (log/(label+'.stdout')).open('xb').write(p.stdout)
    (log/(label+'.stderr')).open('xb').write(p.stderr)
    if p.returncode:raise RuntimeError(label+' failed, preserve logs; no retry')
