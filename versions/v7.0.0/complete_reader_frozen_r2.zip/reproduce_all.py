"""Offline complete V7 reader: unchanged base archive plus the two-world illustration."""
from pathlib import Path
import argparse,json,sys
from reader_common import ROOT,verify,extract,run,sha

def main():
    p=argparse.ArgumentParser()
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--verify-only',action='store_true')
    g.add_argument('--out',type=Path)
    a=p.parse_args()
    assert sys.version_info>=(3,10)
    count=verify()
    if a.verify_only:
        print(json.dumps(dict(state='hashes_and_recursive_archive_CRC_verified',files=count,scientific_executions=0)))
        return
    out=a.out.resolve()
    if out==ROOT or out in ROOT.parents:
        raise ValueError('Output cannot contain this reader')
    out.mkdir(parents=True,exist_ok=False)
    base=out/'sources/base_reader'
    witness=out/'witness_results'
    extract(ROOT/'components/base_reader.zip',base)
    extract(ROOT/'components/witness.zip',witness)
    run(out,'base_verify',base,'reproduce_all.py','--verify-only')
    run(out,'base_replay',base,'reproduce_all.py','--out',out/'base_results')
    run(out,'witness_motion',witness,'worker.py')
    run(out,'witness_reference',witness,'audit.py')
    for name in ['RESULT.json','AUDIT_RESULT.json','ROWS.jsonl','ALLOCATION_ROWS.jsonl']:
        assert (witness/name).read_bytes()==(witness/'reference'/name).read_bytes(),name
    old=json.loads((out/'base_results/REPLAY_RESULT.json').read_text())
    assert old['existing_records_replayed']==10191
    extra=json.loads((witness/'AUDIT_RESULT.json').read_text())
    assert extra['physical_execution_records']==8 and extra['physical_segments']==90
    result=dict(state='all_components_replayed',base_records=10191,illustration_records=8,
        existing_records_replayed=10199,new_unique_scientific_records=0,new_independent_samples=0,
        components_sha256={name:sha(ROOT/'components'/name) for name in ['base_reader.zip','witness.zip']},
        mathematical_proof_or_novelty_certified=False)
    with (out/'REPLAY_RESULT.json').open('x',encoding='utf-8') as handle:
        json.dump(result,handle,indent=2)
    print(json.dumps(result))

if __name__=='__main__':main()
