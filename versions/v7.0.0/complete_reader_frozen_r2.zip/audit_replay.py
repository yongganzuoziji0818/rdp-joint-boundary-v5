"""Independent complete-output audit; does not import the outer replay driver."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys

ROOT=Path(__file__).resolve().parent
def rd(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',required=True,type=Path)
    out=parser.parse_args().out.resolve()
    for name,h in rd(ROOT/'MANIFEST.json').items():assert sha(ROOT/name)==h,name
    base=out/'sources/base_reader'
    result=subprocess.run([sys.executable,'-s','-B',str(base/'audit_replay.py'),'--out',str(out/'base_results')],
        cwd=base,capture_output=True,timeout=40)
    (out/'base_audit.stdout').open('xb').write(result.stdout)
    (out/'base_audit.stderr').open('xb').write(result.stderr)
    assert result.returncode==0,result.stderr.decode(errors='replace')
    old=rd(out/'base_results/INDEPENDENT_AUDIT.json')
    assert old['existing_records_replayed']==10191 and len(old['scientific_files_compared'])==37
    witness=out/'witness_results'
    compared=[]
    for name in ['RESULT.json','AUDIT_RESULT.json','ROWS.jsonl','ALLOCATION_ROWS.jsonl']:
        actual=witness/name
        reference=witness/'reference'/name
        assert actual.read_bytes()==reference.read_bytes(),name
        compared.append(dict(name=name,comparison='bytes',sha256=sha(actual)))
    motion=[json.loads(line) for line in (witness/'ROWS.jsonl').read_text().splitlines()]
    allocations=[json.loads(line) for line in (witness/'ALLOCATION_ROWS.jsonl').read_text().splitlines()]
    assert len(motion)==8 and len(allocations)==96
    extra=rd(witness/'AUDIT_RESULT.json')
    assert extra['same_B_coverage_P_alpha'] and extra['different_deadline_decisions']
    assert [(x['OPT'],x['deadline_feasible']) for x in extra['worlds']]==[('14',False),('12',True)]
    result=dict(state='independent_complete_output_comparison_passed',
        base_scientific_files_compared=37,base_v7_trajectory_rows_compared=5632,
        illustration_files_compared=compared,illustration_trajectory_rows=8,illustration_allocation_rows=96,
        existing_records_replayed=10199,new_unique_scientific_records=0,new_independent_samples=0,
        full_theorem_or_novelty_certified=False)
    with (out/'INDEPENDENT_AUDIT.json').open('x',encoding='utf-8') as handle:
        json.dump(result,handle,indent=2)
    print(json.dumps(result))

if __name__=='__main__':main()
