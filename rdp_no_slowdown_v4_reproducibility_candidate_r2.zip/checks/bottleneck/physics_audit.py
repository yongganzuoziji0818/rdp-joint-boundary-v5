"""No imports from the mission policy/model; independent full-route oracle and replay."""
import itertools
import json
from fractions import Fraction as Q
from pathlib import Path

root = Path(__file__).resolve().parent
result = json.loads((root / 'MISSION_RESULT.json').read_text())
inputs = json.loads((root / 'INPUTS.json').read_text())
f = lambda x: Q(*x)
rat = lambda x: [x.numerator, x.denominator]
summaries, aliases = [], {}
legs = waits = assignments = residual = 0
for case, spec, reference in zip(result['cases'], inputs['cases'], result['assessment']):
    assert case['spec'] == spec == reference['spec']
    alpha, eps = f(spec['alpha']), f(spec['epsilon'])
    r, c, w, T = 2 / alpha, 2 - eps, eps / alpha, (2 + eps) / alpha
    assert alpha == 4 and eps == 4 / (2 * alpha + 1)
    assert w == 2 * (r - eps) < 2 / alpha**2
    assert 2 * r + 2 * c == 4 + w and T + 4 - r == 4 + w
    edges = {tuple(sorted((u, v))): f(value) for u, v, value in spec['edges']}
    dist = {(u, v): Q(0) if u == v else edges.get(tuple(sorted((u, v))))
            for u, v in itertools.product(range(5), repeat=2)}
    for k in range(5):
        for u, v in itertools.product(range(5), repeat=2):
            if dist[u, k] is not None and dist[k, v] is not None:
                via = dist[u, k] + dist[k, v]
                if dist[u, v] is None or via < dist[u, v]:
                    dist[u, v] = via
    def tour(mask, initial=0):
        nodes = [v for v in range(1, 5) if mask & (1 << (v - 1))]
        return min(sum((dist[a, b] for a, b in zip((initial,) + p, p + (0,))), Q(0))
                   for p in itertools.permutations(nodes))
    lengths = {mask: tour(mask) for mask in range(16)}
    offline = []
    for world in range(16):
        costs = []
        for mask in range(16):
            if world & ~mask == 0:
                costs.append(max(lengths[mask], lengths[15 ^ mask] / alpha))
                assignments += 1
        offline.append(min(costs))
    assert lengths[15] == f(case['B']) == 4
    assert offline == list(map(f, reference['offline']))
    assert offline[0] == offline[1] == offline[8] == 2 * r
    assert offline[9] == 4 * r
    for z in [2, 3]:
        assert tour((1 << (z - 1)) | 8, initial=1) == 4 - r
        residual += 1
    opposite = spec['kind'] == 'opposite'
    flight_nodes = [0, 4, 3, 2, 1, 0] if opposite else [0, 1, 2, 3, 4, 0]
    flight, reports, clock = [], {}, Q(0)
    for a, b in zip(flight_nodes, flight_nodes[1:]):
        end = clock + edges[tuple(sorted((a, b)))] / alpha
        flight.append({'u': a, 'v': b, 't0': rat(clock), 't1': rat(end)})
        if b:
            reports[b] = end
        clock = end
    assert clock == 2 * r
    values = []
    for world, row in enumerate(case['runs']):
        seen = 1 | sum(1 << (v - 1) for v, at in reports.items() if at <= r)
        positive = world & seen
        expected = [{'clock': rat(r), 'node': 1, 'seen': seen, 'positive': positive}]
        gap = None
        if (opposite and positive & 12) or (not opposite and positive & 2):
            sequence = [0, 1, 2, 3, 4, 0]
            expected[-1].update(decision='finish_ring', route=[2, 3, 4], depart=rat(r))
        elif opposite:
            assert seen == 13
            expected[-1].update(decision='wait_u', route=None, depart=rat(T))
            seen |= sum(1 << (v - 1) for v, at in reports.items() if at <= T)
            assert seen == 15
            positive = world & seen
            sequence = [0, 1, 2, 1, 0] if positive & 2 else [0, 1, 0]
            gap = (r, T)
            expected.append({'clock': rat(T), 'node': 1, 'seen': seen, 'positive': positive,
                             'decision': 'after_u', 'route': [2, 1] if positive & 2 else [], 'depart': rat(T)})
        else:
            assert seen == 3
            expected[-1].update(decision='return_before_v', route=[], depart=rat(r))
            seen |= sum(1 << (v - 1) for v, at in reports.items() if at <= 2 * r)
            assert seen == 15
            positive = world & seen
            route = [4, 3] if positive & 4 else ([4] if positive & 8 else [])
            sequence = [0, 1, 0] + ([4, 3, 4, 0] if positive & 4 else ([4, 0] if positive & 8 else []))
            expected.append({'clock': rat(2 * r), 'node': 0, 'seen': seen, 'positive': positive,
                             'decision': 'after_full_report', 'route': route, 'depart': rat(2 * r)})
        assert row['world'] == world and row['events'] == expected and row['flight'] == [flight]
        for event in expected:
            key = (spec['id'], tuple(event['clock']), event['node'], event['seen'], event['positive'])
            action = (event['decision'], str(event['route']), tuple(event['depart']))
            assert key not in aliases or aliases[key] == action
            aliases[key] = action
        walk = row['ground'][0]
        assert len(row['ground']) == 1 and len(walk) == len(sequence) - 1
        clock, served = Q(0), 0
        for index, (piece, a, b) in enumerate(zip(walk, sequence, sequence[1:])):
            edge = tuple(sorted((a, b)))
            length = edges[edge]
            begin = T if gap and index == 1 else clock
            if begin > clock:
                assert a == 1 and (clock, begin) == gap
                waits += 1
            x, y = (Q(0), length) if a < b else (length, Q(0))
            end = begin + length
            assert piece == {'edge': list(edge), 'x0': rat(x), 'x1': rat(y), 't0': rat(begin), 't1': rat(end)}
            clock = end
            if b:
                served |= 1 << (b - 1)
            legs += 1
        assert sequence[-1] == 0 and world & ~served == 0
        value = max(clock, 2 * r)
        assert value == f(row['time']) <= 4 + f(spec['slack_s'])
        values.append(value)
    means = [(values[world] + values[int(format(world, '04b')[::-1], 2)]) / (2 * offline[world])
             for world in range(16)]
    target = Q(23, 9) if opposite else Q(3, 2)
    worst = max(values[i] / offline[i] for i in range(16))
    assert max(means) == target and worst == (alpha if opposite else Q(2))
    summaries.append({'id': spec['id'], 'worlds': 16, 'worst_expected_ratio': str(target),
                      'worst_seed_ratio': str(worst), 'all_budget_pass': True,
                      'all_worlds_two_competitive': worst <= 2})
assert result['runs'] == 32 and len(summaries) == 2
audit = {'state': 'independent_floyd_partition_physical_causal_complete', 'runs': 32,
         'node_to_node_legs': legs, 'wait_gaps': waits, 'nonanticipativity_keys': len(aliases),
         'offline_assignments_checked': assignments, 'residual_cost_checks': residual,
         'summary': summaries, 'universal_proof_or_novelty_certified': False}
with (root / 'MISSION_AUDIT.json').open('x') as fobj:
    json.dump(audit, fobj, indent=2)
print(json.dumps({k: v for k, v in audit.items() if k != 'summary'}))
