import json
from fractions import Fraction as F
from pathlib import Path
root=Path(__file__).resolve().parent
rat=lambda x:[x.numerator,x.denominator]
def mirror_mask(w):return sum(((w>>(v-1))&1)<<(4-v) for v in range(1,5))
def node_map(v):return 0 if v==0 else 5-v
def normalized(e,x,L):
    u,v=e
    if x==0:return ('node',u)
    if x==L:return ('node',v)
    return ('point',min(u,v),max(u,v),x if u<v else L-x)
def validate_reflection(spec,row,world):
    edges={tuple(sorted((u,v))):F(*w) for u,v,w in spec['edges']};alpha=F(*spec['alpha'])
    done=seen=0;lasts=[];pieces=0
    for ll in row['ground']:
        state=('node',0);last=F(0)
        for p in ll:
            u,v=p['edge'];mapped=(node_map(u),node_map(v));L=edges[tuple(sorted(mapped))]
            assert L==edges[u,v]
            x,y=F(*p['x0']),F(*p['x1']);t0,t1=F(*p['t0']),F(*p['t1'])
            assert 0<=x<=L and 0<=y<=L and t1-t0==abs(y-x) and t0>=last
            assert normalized(mapped,x,L)==state
            state=normalized(mapped,y,L);last=t1;pieces+=1
            if state[0]=='node' and state[1]:done|=1<<(state[1]-1)
        assert state==('node',0);lasts.append(last)
    seen=done
    for ll in row['flight']:
        state=0;last=F(0)
        for p in ll:
            u,v=node_map(p['u']),node_map(p['v']);L=edges[tuple(sorted((u,v)))]
            t0,t1=F(*p['t0']),F(*p['t1'])
            assert u==state and t0>=last and t1-t0==L/alpha
            state=v;last=t1;pieces+=1
            if v:seen|=1<<(v-1)
        assert state==0;lasts.append(last)
    assert seen==15 and world&~done==0 and max(lasts)==F(*row['time'])
    return pieces
cases=[];piece_count=0
for name in ['MISSION_RESULT.json']:
    source=json.loads((root/name).read_text())
    for case,ref in zip(source['cases'],source['assessment']):
        spec=case['spec'];assert spec==ref['spec'] and spec['n']==4 and spec['m']==spec['k']==1
        budget=F(*case['B'])+F(*spec.get('slack_s',[0,1]));out=[]
        for w in range(16):
            other=mirror_mask(w);left,right=case['runs'][w],case['runs'][other]
            assert left['world']==w and right['world']==other
            a,b=F(*left['time']),F(*right['time']);opt=F(*ref['offline'][w])
            assert opt==F(*ref['offline'][other]) and a<=budget and b<=budget
            piece_count+=validate_reflection(spec,right,w)
            out.append({'world':w,'mirror_world':other,'seed_costs':[rat(a),rat(b)],'weights':[[1,2],[1,2]],
                'expected_time':rat((a+b)/2),'OPT':rat(opt),'expected_ratio':str((a+b)/(2*opt)),
                'tail_probability_above_2OPT':str(F(int(a>2*opt)+int(b>2*opt),2)),
                'worst_seed_ratio':str(max(a,b)/opt)})
        cases.append({'id':spec['id'],'source':name,'budget':rat(budget),'rows':out,
            'worst_expected_ratio':str(max(F(r['expected_ratio']) for r in out)),
            'worst_tail_probability_above_2OPT':str(max(F(r['tail_probability_above_2OPT']) for r in out))})
result={'state':'fixed_half_half_mirror_costs_and_physical_paths_checked','configurations':len(cases),
    'expected_world_values':sum(len(c['rows']) for c in cases),'new_mission_executions':0,
    'reflected_physical_fragments_checked':piece_count,'cases':cases,'all_graph_expected_guarantee_established':False}
assert len(cases)==2 and result['expected_world_values']==32
(root/'RESULT.json').open('x').write(json.dumps(result,separators=(',',':')))
print(json.dumps({k:v for k,v in result.items() if k!='cases'}))
