"""Two fixed ordinary policies; hidden demand is accessible only through observe()."""
import json
import time
from fractions import Fraction as F
from pathlib import Path
from model import Experiment, rat

root = Path(__file__).resolve().parent
inputs = json.loads((root / 'INPUTS.json').read_text())
start = time.process_time()

def run(env, observe):
    g, alpha = env.g, env.alpha
    r, T = 2 / alpha, (2 + F(*env.spec['epsilon'])) / alpha
    opposite = env.spec['kind'] == 'opposite'
    flight, _ = g.trace((4, 3, 2, 1) if opposite else (1, 2, 3, 4), alpha)
    ground, arrival = g.trace((1,), back=False)
    assert arrival == r
    seen = 1 | env.mask([flight], r)
    positive = observe(seen)
    events = [{'clock': rat(r), 'node': 1, 'seen': seen, 'positive': positive}]
    if (opposite and positive & 12) or (not opposite and positive & 2):
        events[-1].update(decision='finish_ring', route=[2, 3, 4], depart=rat(r))
        tail, _ = g.trace((2, 3, 4), start=1, clock=r)
    elif opposite:
        assert seen == 13
        events[-1].update(decision='wait_u', route=None, depart=rat(T))
        seen |= env.mask([flight], T)
        positive = observe(seen)
        route = (2, 1) if positive & 2 else ()
        events.append({'clock': rat(T), 'node': 1, 'seen': seen, 'positive': positive,
                       'decision': 'after_u', 'route': list(route), 'depart': rat(T)})
        tail, _ = g.trace(route, start=1, clock=T)
    else:
        assert seen == 3
        events[-1].update(decision='return_before_v', route=[], depart=rat(r))
        ground += g.trace((), start=1, clock=r)[0]
        seen |= env.mask([flight], 2 * r)
        assert seen == 15
        positive = observe(seen)
        route = (4, 3) if positive & 4 else ((4,) if positive & 8 else ())
        events.append({'clock': rat(2 * r), 'node': 0, 'seen': seen, 'positive': positive,
                       'decision': 'after_full_report', 'route': list(route), 'depart': rat(2 * r)})
        tail, _ = g.trace(route, start=0, clock=2 * r)
    ground += tail
    physical = []
    for part in ground:
        u, v = part['u'], part['v']
        length = g.adj[u][v]
        physical.append({'edge': sorted((u, v)), 'x0': rat(F(0) if u < v else length),
                         'x1': rat(length if u < v else F(0)), 't0': part['t0'], 't1': part['t1']})
    return {'policy': 'ordinary_' + env.spec['kind'], 'ground': [physical], 'flight': [flight],
            'events': events, 'time': rat(env.finish([ground], [flight]))}

cases, envs = [], []
for spec in inputs['cases']:
    env = Experiment(spec)
    rows = []
    for world in range(16):
        row = run(env, lambda seen, world=world: world & seen)
        row['world'] = world
        rows.append(row)
    cases.append({'spec': spec, 'B': rat(env.B), 'S': rat(env.S), 'runs': rows})
    envs.append(env)
assessment = []
for case, env in zip(cases, envs):
    offline = [env.fleet(15, (F(1), env.alpha), world)[0] for world in range(16)]
    assessment.append({'spec': case['spec'], 'B': case['B'], 'S': case['S'],
                       'offline': list(map(rat, offline)), 'runs': []})
    assert all(F(*row['time']) <= env.B + F(*case['spec']['slack_s']) for row in case['runs'])
result = {'state': 'ordinary_two_bottleneck_policies_complete', 'cases': cases,
          'assessment': assessment, 'runs': 32, 'cpu_seconds': time.process_time() - start,
          'universal_proof_or_novelty_certified': False}
assert len(cases) == 2 and sum(len(case['runs']) for case in cases) == 32
with (root / 'MISSION_RESULT.json').open('x') as f:
    json.dump(result, f, separators=(',', ':'))
print(json.dumps({'runs': 32, 'cpu_seconds': result['cpu_seconds']}))
