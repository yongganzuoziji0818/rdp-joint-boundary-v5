import runpy
runpy.run_path('mission_worker.py', run_name="__main__")
runpy.run_path('coin_worker.py', run_name="__main__")
