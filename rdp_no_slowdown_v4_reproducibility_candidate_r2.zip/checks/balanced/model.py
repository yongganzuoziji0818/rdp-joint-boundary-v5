"""Small exact physical-network implementation, not an author-code reproduction."""
import functools,heapq,itertools
from fractions import Fraction as F

def rat(x):return [x.numerator,x.denominator]
def number(x):return F(*x)
def compositions(n,k):
    if k==1:yield (n,);return
    for v in range(n+1):
        for tail in compositions(n-v,k-1):yield (v,)+tail
class Network:
    def __init__(self,n,edges):
        self.n=n;self.adj={i:{} for i in range(n+1)}
        for u,v,w in edges:
            assert u!=v and w>0 and v not in self.adj[u]
            self.adj[u][v]=self.adj[v][u]=w
    @functools.lru_cache(None)
    def shortest(self,start,goal):
        queue=[(F(0),0,(start,))];seen={}
        while queue:
            value,hops,path=heapq.heappop(queue);u=path[-1]
            if u in seen:continue
            seen[u]=(value,hops,path)
            if u==goal:return value,path
            for v,w in sorted(self.adj[u].items()):
                if v not in seen:heapq.heappush(queue,(value+w,hops+1,path+(v,)))
        raise AssertionError('Disconnected graph')
    def with_position(self,state):
        if 'edge' not in state:return self
        edges=[(u,v,w) for u in self.adj for v,w in self.adj[u].items() if u<v]
        g=Network(self.n,edges);u,v=state['edge'];x=number(state['offset']);length=self.adj[u][v];node=state['position']
        assert 0<x<length and node>self.n
        g.adj[node]={u:x,v:length-x};g.adj[u][node]=x;g.adj[v][node]=length-x
        return g
    def trace(self,order,speed=F(1),start=0,clock=F(0),back=True):
        out=[];here=start
        for goal in tuple(order)+((0,) if back else ()):
            _,path=self.shortest(here,goal)
            for v in path[1:]:
                end=clock+self.adj[here][v]/speed
                out.append({'u':here,'v':v,'t0':rat(clock),'t1':rat(end)});here,clock=v,end
        return out,clock
    def cut(self,full,clock,vehicle):
        prefix=[];suffix=[];position=0;state=None
        for leg in full:
            begin,end=number(leg['t0']),number(leg['t1'])
            if end<=clock:prefix.append(leg);position=leg['v']
            elif begin>=clock:
                if state is None:state={'position':leg['u'],'clock':rat(clock)}
                suffix.append(leg)
            else:
                assert state is None
                position=self.n+1+vehicle;state={'position':position,'clock':rat(clock),'edge':[leg['u'],leg['v']],'offset':rat(clock-begin)}
                prefix.append(dict(leg,v=position,t1=rat(clock)));suffix.append(dict(leg,u=position,t0=rat(clock)))
        if state is None:state={'position':position,'clock':rat(clock)}
        return prefix,suffix,state

class Experiment:
    def __init__(self,spec):
        self.spec=spec;self.n=spec['n'];self.m=spec['m'];self.k=spec['k'];self.alpha=number(spec['alpha']);self.full=(1<<self.n)-1
        self.g=Network(self.n,[(u,v,number(w)) for u,v,w in spec['edges']])
        self.B,self.trucks=self.fleet(self.full,(F(1),)*self.m)
        self.S,self.scouts=self.fleet(self.full,(self.alpha,)*self.k)
        self.M,self.mixed=self.fleet(self.full,(F(1),)*self.m+(self.alpha,)*self.k)
        self.full_ground=[self.g.trace(p)[0] for p in self.trucks]
        self.full_flight=[self.g.trace(p,self.alpha)[0] for p in self.scouts]
    @functools.lru_cache(None)
    def tour(self,mask,start=0):
        nodes=tuple(v for v in range(1,self.n+1) if mask&(1<<(v-1)))
        return min((self.g.trace(order,start=start)[1],order) for order in itertools.permutations(nodes))
    @functools.lru_cache(None)
    def fleet(self,mask,speeds,forced=0):
        nodes=tuple(v for v in range(1,self.n+1) if mask&(1<<(v-1)));options=[]
        for who in itertools.product(range(len(speeds)),repeat=len(nodes)):
            if any(forced&(1<<(v-1)) and j>=self.m for v,j in zip(nodes,who)):continue
            masks=tuple(sum(1<<(v-1) for v,j in zip(nodes,who) if j==a) for a in range(len(speeds)))
            tours=[self.tour(mm) for mm in masks];options.append((max(t[0]/s for t,s in zip(tours,speeds)),tuple(t[1] for t in tours)))
        return min(options)
    def mask(self,legs,at=None):
        return sum(1<<(v-1) for v in {leg['v'] for ll in legs for leg in ll if 1<=leg['v']<=self.n and (at is None or number(leg['t1'])<=at)})
    def finish(self,ground,flight):return max([F(0)]+[number(leg['t1']) for ll in ground+flight for leg in ll])
    def regretless(self,world):
        counts=[self.k//self.m+int(i<self.k%self.m) for i in range(self.m)]
        gg=[];ff=[];decisions=[]
        for route,q in zip(self.trucks,counts):
            options=[]
            for cc in compositions(len(route),q+1):
                point=cc[0];blocks=[]
                for length in cc[1:]:blocks.append(tuple(reversed(route[point:point+length])));point+=length
                costs=[self.g.trace(route[:cc[0]])[1]]+[self.g.trace(b,self.alpha)[1] for b in blocks]
                options.append((max(costs),cc,tuple(blocks)))
            phase,cc,blocks=min(options);dr=[self.g.trace(block,self.alpha)[0] for block in blocks]
            prefix,theta=self.g.trace(route[:cc[0]],back=False)
            seen=self.mask(dr,theta)|self.mask([prefix]);done=self.mask([prefix]);own=sum(1<<(v-1) for v in route)
            known=world&seen;need=(own&~seen)|(known&~done);current=route[cc[0]-1] if cc[0] else 0
            _,suffix=self.tour(need,current);tail,last=self.g.trace(suffix,start=current,clock=theta)
            gg.append(prefix+tail);ff.extend(dr);decisions.append({'composition':cc,'phase':rat(phase),'trigger':rat(theta),
                'seen':seen,'known_positive':known,'served':done,'need':need,'suffix':suffix})
        return {'policy':'regretless_fixed_lex_allow_empty','world':world,'ground':gg,'flight':ff,'decisions':decisions,
            'drones_per_truck':counts,'time':rat(self.finish(gg,ff))}
    def optimistic(self,world):
        gg=[self.g.trace(p)[0] for p in self.mixed[:self.m]];ff=[self.g.trace(p,self.alpha)[0] for p in self.mixed[self.m:]]
        assert self.mask(gg+ff,self.M)==self.full
        need=world&~self.mask(gg);value,routes=self.fleet(need,(F(1),)*self.m)
        counts=[]
        for j,p in enumerate(routes):counts.append(len(gg[j]));gg[j]+=self.g.trace(p,clock=self.M)[0]
        return {'policy':'optimistic_fixed_lex','world':world,'ground':gg,'flight':ff,'phase1_leg_counts':counts,
            'remaining':need,'stage2_routes':routes,'time':rat(self.M+value)}
    def portfolio(self,world,node_only=False):
        policy='node_arrival_restart_control' if node_only else 'concurrent_backup_portfolio'
        if self.S>self.B:
            return {'policy':policy,'world':world,'ground':self.full_ground,'flight':[[] for _ in range(self.k)],
                'branch':'do_not_launch','time':rat(self.B)}
        clock=self.S
        if node_only:
            assert self.m==1
            clock=min(number(leg['t1']) for leg in self.full_ground[0] if number(leg['t1'])>=self.S)
        cut=[self.g.cut(ll,clock,j) for j,ll in enumerate(self.full_ground)]
        prefix=[v[0] for v in cut];backup=[v[1] for v in cut];states=[v[2] for v in cut]
        assert self.mask(self.full_flight,clock)==self.full
        done=self.mask(prefix);known=world&self.mask(self.full_flight,clock);need=known&~done
        value,routes=self.fleet(need,(F(1),)*self.m);returns=[];back=[]
        for state in states:
            graph=self.g.with_position(state);ll,end=graph.trace((),start=state['position'],clock=clock);returns.append(end-clock);back.append(ll)
        rho=max(returns);candidate=clock+rho+value;restart=candidate<self.B
        ground=[];plens=[];rlens=[]
        for j in range(self.m):
            plens.append(len(prefix[j]));rlens.append(len(back[j]) if restart else 0)
            if restart:ground.append(prefix[j]+back[j]+self.g.trace(routes[j],clock=clock+rho)[0])
            else:ground.append(prefix[j]+backup[j])
        actual=self.finish(ground,self.full_flight)
        assert actual==min(self.B,candidate)
        return {'policy':policy,'world':world,'branch':'restart' if restart else 'continue_backup','clock':rat(clock),'states':states,
            'known_mask':self.full,'known_positive':known,'served':done,'remaining':need,'return_times':[rat(v) for v in returns],
            'return_max':rat(rho),'service_value':rat(value),'service_routes':routes,'restart_finish':rat(candidate),
            'prefix_leg_counts':plens,'return_leg_counts':rlens,'ground':ground,'flight':self.full_flight,'time':rat(actual)}
    def nodewise(self,world):
        assert self.m==1
        if self.S>self.B:return {'policy':'ordinary_nodewise_deletion','world':world,'branch':'do_not_launch',
            'ground':self.full_ground,'flight':[[] for _ in range(self.k)],'time':rat(self.B)}
        todo=list(self.trucks[0]);here=0;clock=F(0);visited=0;ground=[];decisions=[]
        for step in range(100):
            seen=visited|self.mask(self.full_flight,clock);positive=world&seen
            todo=[v for v in todo if not (visited&(1<<(v-1))) and not ((seen&(1<<(v-1))) and not (positive&(1<<(v-1))))]
            target=todo[0] if todo else 0
            decision={'position':here,'time':rat(clock),'seen':seen,'positive':positive,'visited':visited,'todo':list(todo),'target':target}
            decisions.append(decision)
            if here==target:assert here==0;break
            _,path=self.g.shortest(here,target);following=path[1];end=clock+self.g.adj[here][following]
            ground.append({'u':here,'v':following,'t0':rat(clock),'t1':rat(end)});decision['following']=following
            here,clock=following,end
            if here:visited|=1<<(here-1)
        else:raise AssertionError('Nodewise loop cap')
        return {'policy':'ordinary_nodewise_deletion','world':world,'branch':'run','ground':[ground],'flight':self.full_flight,
            'decisions':decisions,'time':rat(self.finish([ground],self.full_flight))}
