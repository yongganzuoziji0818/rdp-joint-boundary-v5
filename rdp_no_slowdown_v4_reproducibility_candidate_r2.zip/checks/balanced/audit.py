import runpy
runpy.run_path('physics_audit.py', run_name="__main__")
runpy.run_path('coin_audit.py', run_name="__main__")
