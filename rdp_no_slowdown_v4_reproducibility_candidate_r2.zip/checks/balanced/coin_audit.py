"""Independent coordinate reflection and two-atom distribution verification."""
import itertools,json
from fractions import Fraction as Q
from pathlib import Path
root=Path(__file__).resolve().parent
result=json.loads((root/'RESULT.json').read_text());total=segments=distance_tests=0;summaries=[]
allcases=[]
for filename in ['MISSION_RESULT.json']:
    obj=json.loads((root/filename).read_text())
    allcases.extend((filename,c,a) for c,a in zip(obj['cases'],obj['assessment']))
for output,(filename,case,reference) in zip(result['cases'],allcases):
    sp=case['spec'];a=Q(*sp['alpha']);eps=Q(*sp['epsilon']);r=2/a;c=2-eps
    coords=[Q(0),r,c,4-c,4-r];at={x:i for i,x in enumerate(coords)}
    swap={i:at[(-x)%4] for i,x in enumerate(coords)}
    edges={tuple(sorted((u,v))):Q(*value) for u,v,value in sp['edges']}
    matrix={(u,v):Q(0) if u==v else edges.get(tuple(sorted((u,v)))) for u,v in itertools.product(range(5),repeat=2)}
    for k in range(5):
        for i,j in itertools.product(range(5),repeat=2):
            if matrix[i,k] is not None and matrix[k,j] is not None:
                x=matrix[i,k]+matrix[k,j]
                if matrix[i,j] is None or x<matrix[i,j]:matrix[i,j]=x
    for i,j in itertools.product(range(5),repeat=2):
        assert matrix[i,j]==matrix[swap[i],swap[j]];distance_tests+=1
    for (u,v),length in edges.items():assert edges[tuple(sorted((swap[u],swap[v]))) ]==length
    budget=Q(*case['B'])+Q(*sp.get('slack_s',[0,1]));means=[];tails=[];maxratio=[]
    assert output['id']==sp['id'] and output['source']==filename and Q(*output['budget'])==budget
    for w,row in enumerate(output['rows']):
        opposite=int(format(w,'04b')[::-1],2);assert row['world']==w and row['mirror_world']==opposite
        costs=[Q(*case['runs'][w]['time']),Q(*case['runs'][opposite]['time'])]
        opt=Q(*reference['offline'][w]);assert opt==Q(*reference['offline'][opposite])
        for seed,value in enumerate(costs):assert Q(*row['seed_costs'][seed])==value<=budget and Q(*row['weights'][seed])==Q(1,2)
        mean=sum(costs,Q(0))/2;tail=sum(Q(1,2) for value in costs if value>2*opt)
        assert Q(*row['expected_time'])==mean and Q(*row['OPT'])==opt
        assert Q(row['expected_ratio'])==mean/opt and Q(row['tail_probability_above_2OPT'])==tail
        assert Q(row['worst_seed_ratio'])==max(costs)/opt
        means.append(mean/opt);tails.append(tail);maxratio.append(max(costs)/opt);total+=1
        # Reflected source path is checked in scalar physical ring coordinates, not the worker's point tuples.
        original=case['runs'][opposite];ground_seen=set();observed=set();ends=[]
        for trajectory in original['ground']:
            pos=Q(0);clock=Q(0)
            for fragment in trajectory:
                u,v=fragment['edge'];length=edges[u,v]
                direction=1 if coords[v]-coords[u]==length else -1
                assert (coords[u]+direction*length)%4==coords[v]
                start=(-coords[u]-direction*Q(*fragment['x0']))%4
                end=(-coords[u]-direction*Q(*fragment['x1']))%4
                t0,t1=Q(*fragment['t0']),Q(*fragment['t1'])
                assert start==pos and t0>=clock and t1-t0==abs(Q(*fragment['x1'])-Q(*fragment['x0']))
                pos=end;clock=t1;segments+=1
                if end in at:ground_seen.add(at[end])
            assert pos==0;ends.append(clock)
        observed.update(ground_seen)
        for trajectory in original['flight']:
            pos=Q(0);clock=Q(0)
            for fragment in trajectory:
                u,v=fragment['u'],fragment['v'];t0,t1=Q(*fragment['t0']),Q(*fragment['t1'])
                assert (-coords[u])%4==pos and t0>=clock and t1-t0==edges[tuple(sorted((u,v)))]/a
                pos=(-coords[v])%4;clock=t1;observed.add(at[pos]);segments+=1
            assert pos==0;ends.append(clock)
        assert set(range(1,5))<=observed
        assert all(v in ground_seen for v in range(1,5) if w&(1<<(v-1)))
        assert max(ends)==costs[1]
    assert Q(output['worst_expected_ratio'])==max(means) and Q(output['worst_tail_probability_above_2OPT'])==max(tails)
    summaries.append({'id':sp['id'],'worst_expected_ratio':str(max(means)),
        'worst_tail_probability_above_2OPT':str(max(tails)),'worst_seed_ratio':str(max(maxratio)),
        'all_worlds_expected_at_most_2':max(means)<=2,'pathwise_budget_verified':True})
assert total==48 and segments==result['reflected_physical_fragments_checked'] and len(summaries)==3
audit={'state':'independent_coordinate_isometry_distribution_physical_audit_complete','configurations':3,
    'expected_world_values':total,'new_mission_executions':0,'physical_segments':segments,
    'distance_isometry_tests':distance_tests,'summary':summaries,'general_randomized_policy_bound_proved':False}
(root/'AUDIT.json').open('x').write(json.dumps(audit,indent=2))
print(json.dumps({k:v for k,v in audit.items() if k!='summary'}))
