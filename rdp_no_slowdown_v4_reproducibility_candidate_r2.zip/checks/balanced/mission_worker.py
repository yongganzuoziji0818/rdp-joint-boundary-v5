"""Map-only opposite flight, ordinary two-step causal truck rule."""
import json
import time
from fractions import Fraction as F
from pathlib import Path
from model import Experiment, rat

root = Path(__file__).resolve().parent
inputs = json.loads((root / 'INPUTS.json').read_text())
start = time.process_time()

def run(env, observe):
    g, alpha = env.g, env.alpha
    r, c = F(2) / alpha, 2 - F(*env.spec['epsilon'])
    T = (4 - c) / alpha
    flight, end = g.trace((4, 3, 2, 1), alpha)
    assert end == 4 / alpha
    prefix, arrival = g.trace((1,), back=False)
    assert arrival == r
    seen = (1 << 0) | env.mask([flight], r)
    assert seen == 13
    positive = observe(seen)
    events = [{'clock': rat(r), 'node': 1, 'seen': seen, 'positive': positive}]
    if positive & 12:
        route = (2, 3, 4)
        depart = r
        events[-1].update(decision='finish_original_ring', route=list(route), depart=rat(depart))
    else:
        # Time T follows solely from the frozen flight route, not from hidden demand.
        seen |= env.mask([flight], T)
        assert seen == 15
        positive = observe(seen)
        route = (2, 1) if positive & 2 else ()
        depart = T
        events[-1].update(decision='wait_for_u', route=None, depart=rat(T))
        events.append({'clock': rat(T), 'node': 1, 'seen': seen, 'positive': positive,
                       'decision': 'serve_u_then_return' if positive & 2 else 'return',
                       'route': list(route), 'depart': rat(T)})
    suffix, _ = g.trace(route, start=1, clock=depart)
    raw_ground = prefix + suffix
    ground = []
    for leg in raw_ground:
        u, v = leg['u'], leg['v']
        edge = sorted((u, v))
        L = g.adj[u][v]
        ground.append({'edge': edge, 'x0': rat(F(0) if u < v else L),
                       'x1': rat(L if u < v else F(0)), 't0': leg['t0'], 't1': leg['t1']})
    return {'policy': 'opposite_scout_conditional_node_wait', 'time': rat(env.finish([raw_ground], [flight])),
            'ground': [ground], 'flight': [flight], 'events': events}

cases, envs = [], []
for spec in inputs['cases']:
    env = Experiment(spec)
    rows = []
    for world in range(16):
        row = run(env, lambda seen, world=world: world & seen)
        row['world'] = world
        rows.append(row)
    cases.append({'spec': spec, 'B': rat(env.B), 'S': rat(env.S), 'runs': rows})
    envs.append(env)
# OPT is assessed only after the complete causal task records exist.
assessment, violations = [], []
for case, env in zip(cases, envs):
    offline = [env.fleet(15, (F(1), env.alpha), w)[0] for w in range(16)]
    assessment.append({'spec': case['spec'], 'B': case['B'], 'S': case['S'],
                       'offline': list(map(rat, offline)), 'runs': []})
    for row in case['runs']:
        value, opt = F(*row['time']), offline[row['world']]
        assert value <= env.B == 4
        if value > 2 * opt:
            violations.append({'id': case['spec']['id'], 'world': row['world'],
                               'ratio': str(value / opt)})
result = {'state': 'opposite_scout_ordinary_rule_complete', 'cases': cases,
          'assessment': assessment, 'runs': sum(len(c['runs']) for c in cases),
          'two_competitive_counterexamples': violations,
          'cpu_seconds': time.process_time() - start,
          'universal_proof_or_novelty_certified': False}
assert len(cases) == 3 and result['runs'] == 48
with (root / 'MISSION_RESULT.json').open('x') as f:
    json.dump(result, f, separators=(',', ':'))
print(json.dumps({'runs': 48, 'cpu_seconds': result['cpu_seconds']}))
