"""Independent Floyd, brute partitions/permutations and physical causal replay."""
import itertools
import json
from fractions import Fraction as Q
from pathlib import Path

root = Path(__file__).resolve().parent
result = json.loads((root / 'MISSION_RESULT.json').read_text())
inputs = json.loads((root / 'INPUTS.json').read_text())
f = lambda value: Q(*value)
rat = lambda value: [value.numerator, value.denominator]
aliases, summaries = {}, []
segments = wait_count = oracle_count = residual_tests = 0
for case, spec, reference in zip(result['cases'], inputs['cases'], result['assessment']):
    assert case['spec'] == spec == reference['spec']
    alpha, eps = f(spec['alpha']), f(spec['epsilon'])
    r, c, T = 2 / alpha, 2 - eps, (2 + eps) / alpha
    w = eps / alpha
    edges = {tuple(sorted((u, v))): f(value) for u, v, value in spec['edges']}
    dist = {(i, j): Q(0) if i == j else edges.get(tuple(sorted((i, j))))
            for i, j in itertools.product(range(5), repeat=2)}
    for k in range(5):
        for i, j in itertools.product(range(5), repeat=2):
            if dist[i, k] is not None and dist[k, j] is not None:
                value = dist[i, k] + dist[k, j]
                if dist[i, j] is None or value < dist[i, j]:
                    dist[i, j] = value
    def tour(mask, initial=0):
        targets = [i for i in range(1, 5) if mask & (1 << (i - 1))]
        return min(sum((dist[i, j] for i, j in zip((initial,) + p, p + (0,))), Q(0))
                   for p in itertools.permutations(targets))
    lengths = {mask: tour(mask) for mask in range(16)}
    offline = []
    for world in range(16):
        values = []
        for assigned in range(16):
            if world & ~assigned == 0:
                # Duplicate inspection cannot improve over this disjoint partition:
                # shortcutting a redundant inspection never delays either vehicle.
                values.append(max(lengths[assigned], lengths[15 ^ assigned] / alpha))
                oracle_count += 1
        offline.append(min(values))
    assert lengths[15] == f(case['B']) == 4
    assert lengths[15] / alpha == f(case['S'])
    assert offline == list(map(f, reference['offline']))
    assert offline[0] == offline[1] == offline[8] == 2 * r
    assert offline[9] == 4 * r
    for z in (2, 3):
        assert tour((1 << (z - 1)) | 8, initial=1) == 4 - r
        assert 2 * r + 2 * c > 4 + 2 / alpha**2
        residual_tests += 2
    flight_vertices = [0, 4, 3, 2, 1, 0]
    report, clock, flight = {}, Q(0), []
    for a, b in zip(flight_vertices, flight_vertices[1:]):
        end = clock + edges[tuple(sorted((a, b)))] / alpha
        flight.append({'u': a, 'v': b, 't0': rat(clock), 't1': rat(end)})
        if b:
            report[b] = end
        clock = end
    assert report[4] == r / alpha and report[3] == c / alpha < r < report[2] == T
    values, worlds_waited = [], []
    for world, row in enumerate(case['runs']):
        assert row['world'] == world and row['flight'] == [flight]
        known = 1 | sum(1 << (v - 1) for v, when in report.items() if when <= r)
        assert known == 13
        expected_events = [{'clock': rat(r), 'node': 1, 'seen': known, 'positive': world & known}]
        if world & known & 12:
            sequence, depart = [0, 1, 2, 3, 4, 0], r
            expected_events[-1].update(decision='finish_original_ring', route=[2, 3, 4], depart=rat(r))
        else:
            known |= sum(1 << (v - 1) for v, when in report.items() if when <= T)
            assert known == 15
            positive = world & known
            sequence, depart = ([0, 1, 2, 1, 0] if positive & 2 else [0, 1, 0]), T
            expected_events[-1].update(decision='wait_for_u', route=None, depart=rat(T))
            expected_events.append({'clock': rat(T), 'node': 1, 'seen': known, 'positive': positive,
                                    'decision': 'serve_u_then_return' if positive & 2 else 'return',
                                    'route': [2, 1] if positive & 2 else [], 'depart': rat(T)})
            wait_count += 1
            worlds_waited.append(world)
        assert row['events'] == expected_events
        for event in row['events']:
            key = (spec['id'], tuple(event['clock']), event['node'], event['seen'], event['positive'])
            action = (event['decision'], json.dumps(event['route']), tuple(event['depart']))
            assert key not in aliases or aliases[key] == action
            aliases[key] = action
        assert len(row['ground']) == 1 and len(row['ground'][0]) == len(sequence) - 1
        clock, served, state = Q(0), 0, 0
        for index, (piece, a, b) in enumerate(zip(row['ground'][0], sequence, sequence[1:])):
            edge = tuple(sorted((a, b)))
            L = edges[edge]
            begin = Q(0) if index == 0 else (depart if index == 1 else clock)
            assert state == a and begin >= clock
            if begin > clock:
                assert index == 1 and a == 1 and clock == r and begin == T
            x, y = (Q(0), L) if a < b else (L, Q(0))
            end = begin + L
            assert piece == {'edge': list(edge), 'x0': rat(x), 'x1': rat(y),
                             't0': rat(begin), 't1': rat(end)}
            state, clock = b, end
            if b:
                served |= 1 << (b - 1)
            segments += 1
        assert state == 0 and world & ~served == 0
        value = max(clock, 4 / alpha)
        assert value == f(row['time']) <= 4
        values.append(value)
    L = (alpha + 1 + eps / 4) / 2
    means = [(values[world] + values[int(format(world, '04b')[::-1], 2)]) / (2 * offline[world])
             for world in range(16)]
    assert values[1] / offline[1] == 1 + eps / 4
    assert values[8] / offline[8] == alpha
    assert max(means) == L and max(values[i] / offline[i] for i in range(16)) == alpha
    assert 2 / c < Q(5, 4) < L
    summaries.append({'id': spec['id'], 'worlds': 16, 'worst_expected_ratio': str(L),
                      'worst_seed_ratio': str(alpha), 'pathwise_budget': '4',
                      'all_worlds_expected_at_most_two': L <= 2,
                      'wait_worlds': worlds_waited})
assert result['runs'] == 48 and len(summaries) == 3
audit = {'state': 'independent_floyd_brute_oracle_physical_causal_replay_complete',
         'runs': 48, 'node_to_node_legs': segments, 'wait_gaps': wait_count,
         'nonanticipativity_keys': len(aliases), 'offline_assignments_checked': oracle_count,
         'residual_cost_checks': residual_tests, 'summary': summaries,
         'universal_lower_bound_or_novelty_certified': False}
with (root / 'MISSION_AUDIT.json').open('x') as fobj:
    json.dump(audit, fobj, indent=2)
print(json.dumps({k: v for k, v in audit.items() if k != 'summary'}))
