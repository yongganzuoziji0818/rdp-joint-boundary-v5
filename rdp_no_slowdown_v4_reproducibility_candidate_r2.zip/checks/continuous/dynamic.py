"""Ordinary exact reoptimization at causal information/service events."""
import itertools
from fractions import Fraction as F
from model import rat,number

def vertex(v):return {'node':v}
def point(edge,x):return {'edge':list(edge),'x':rat(x)}
def locate(g,e,x):
    u,v=e;length=g.adj[u][v]
    assert 0<=x<=length and u<v
    return vertex(u) if x==0 else vertex(v) if x==length else point(e,x)
def leg(g,u,v,t):
    edge=tuple(sorted((u,v)));length=g.adj[u][v]
    return {'edge':list(edge),'x0':rat(F(0) if u<v else length),'x1':rat(length if u<v else F(0)),
            't0':rat(t),'t1':rat(t+length)}
def head(g,state,goal):
    if 'node' in state:return g.shortest(state['node'],goal)
    u,v=state['edge'];x=number(state['x']);length=g.adj[u][v]
    return min((x+g.shortest(u,goal)[0],(u,)+g.shortest(u,goal)[1][1:]),
               (length-x+g.shortest(v,goal)[0],(v,)+g.shortest(v,goal)[1][1:]))
def length(g,state,order):
    goals=tuple(order)+(0,);cost=F(0);current=state
    for goal in goals:
        value,_=head(g,current,goal);cost+=value;current=vertex(goal)
    return cost
def trace(g,state,order,t):
    out=[];current=state
    for goal in tuple(order)+(0,):
        _,path=head(g,current,goal)
        if 'edge' in current:
            e=current['edge'];x=number(current['x']);end=F(0) if path[0]==e[0] else g.adj[e[0]][e[1]]
            duration=abs(end-x)
            if duration:
                out.append({'edge':e[:],'x0':rat(x),'x1':rat(end),'t0':rat(t),'t1':rat(t+duration)});t+=duration
        for u,v in zip(path,path[1:]):out.append(leg(g,u,v,t));t=number(out[-1]['t1'])
        current=vertex(goal)
    return out
def advance(g,states,plans,clock):
    states=[dict(s) for s in states];plans=[[dict(p) for p in pp] for pp in plans];executed=[[] for _ in states];arrived=0
    for j in range(len(states)):
        while plans[j] and number(plans[j][0]['t0'])<clock:
            row=plans[j].pop(0);begin,end=number(row['t0']),number(row['t1']);x0,x1=number(row['x0']),number(row['x1'])
            if end<=clock:
                executed[j].append(row);states[j]=locate(g,row['edge'],x1)
                assert 'node' in states[j]
                if states[j]['node']:arrived|=1<<(states[j]['node']-1)
            else:
                x=x0+(clock-begin)*(1 if x1>x0 else -1)
                executed[j].append(dict(row,x1=rat(x),t1=rat(clock)))
                plans[j].insert(0,dict(row,x0=rat(x),t0=rat(clock)));states[j]=locate(g,row['edge'],x);break
    return states,plans,executed,arrived
def solve(g,n,states,need):
    nodes=tuple(v for v in range(1,n+1) if need&(1<<(v-1)));options=[]
    for who in itertools.product(range(len(states)),repeat=len(nodes)):
        tours=[]
        for j,s in enumerate(states):
            subset=tuple(v for v,a in zip(nodes,who) if a==j)
            tours.append(min((length(g,s,p),p) for p in itertools.permutations(subset)))
        options.append((max(v[0] for v in tours),tuple(v[1] for v in tours)))
    return min(options)
def run(env,world,delay=F(0)):
    policy='ordinary_wait_then_exact_reoptimization';g=env.g;m=env.m;budget=env.B+delay
    assert delay>=0
    if env.S>env.B:
        return {'policy':policy,'world':world,'branch':'no_launch','time':rat(env.B),
                'ground':[[leg(g,r['u'],r['v'],number(r['t0'])) for r in ll] for ll in env.full_ground],
                'flight':[[] for _ in range(env.k)],'events':[]}
    # Flight schedule is map-only. World is read only through observed mask below.
    flight=env.full_flight;scout={}
    for ll in flight:
        for r in ll:
            v=r['v']
            if v:scout[v]=min(scout.get(v,number(r['t1'])),number(r['t1']))
    assert len(scout)==env.n
    states=[vertex(0) for _ in range(m)];plans=[trace(g,s,p,delay) for s,p in zip(states,env.trucks)]
    ground=[[] for _ in range(m)];seen=served=0;clock=delay;events=[]
    for index in range(100):
        nexts=[number(pp[0]['t1']) for pp in plans if pp]+[t for v,t in scout.items() if not seen&(1<<(v-1)) and (t>clock or (index==0 and t==clock))]
        if not nexts:break
        clock=min(nexts);before_states=[dict(s) for s in states]
        states,plans,pieces,arrived=advance(g,states,plans,clock)
        for j in range(m):ground[j].extend(pieces[j])
        newseen=arrived|sum(1<<(v-1) for v,t in scout.items() if t<=clock)
        changed=bool(newseen&~seen or arrived&~served);seen|=newseen;served|=arrived
        positive=world&seen;need=env.full&~served&~(seen&~positive)
        oldfinish=max([clock]+[number(p[-1]['t1']) for p in plans if p]);oldplans=plans
        action=None
        if changed:
            value,routes=solve(g,env.n,states,need)
            assert clock+value<=oldfinish<=budget
            plans=[trace(g,s,p,clock) for s,p in zip(states,routes)]
            action={'value':rat(value),'routes':routes}
        events.append({'clock':rat(clock),'states_before_advance':before_states,'states':states,'executed':pieces,
            'arrived':arrived,'seen':seen,'positive':positive,'served':served,'need':need,'changed':changed,
            'old_plans':oldplans,'old_finish':rat(oldfinish),'action':action,'new_plans':plans})
    else:raise AssertionError('event cap')
    assert seen==env.full and world&~served==0 and all(s==vertex(0) for s in states) and not any(plans)
    total=max([env.S]+[number(r['t1']) for ll in ground for r in ll])
    return {'policy':policy,'world':world,'branch':'launched','initial_wait':rat(delay),'ground':ground,'flight':flight,'events':events,'time':rat(total)}
