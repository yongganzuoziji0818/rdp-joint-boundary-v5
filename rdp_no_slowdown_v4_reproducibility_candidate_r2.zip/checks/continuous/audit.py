"""Independent Floyd/subset-DP and physical event replay; imports no policy code."""
import functools,itertools,json
from fractions import Fraction as F
from pathlib import Path
root=Path(__file__).resolve().parent;result=json.loads((root/'RESULT.json').read_text());inputs=json.loads((root/'INPUTS.json').read_text());reference={'cases':result['assessment']}
f=lambda a:F(*a)
def rat(a):return [a.numerator,a.denominator]
total=events_count=pieces_count=dpstates=0;aliases={};summaries=[]
for case,spec,ref in zip(result['cases'],inputs['cases'],reference['cases']):
    assert case['spec']==spec==ref['spec'];n,m,k=spec['n'],spec['m'],spec['k'];alpha=f(spec['alpha']);full=(1<<n)-1
    edges={(u,v):f(w) for u,v,w in spec['edges']};assert all(u<v and w>0 for (u,v),w in edges.items())
    # Floyd is independent of worker's Dijkstra; simple paths separately pin physical tie choices.
    dist={(u,v):F(0) if u==v else edges.get(tuple(sorted((u,v)))) for u,v in itertools.product(range(n+1),repeat=2)}
    for mid in range(n+1):
        for u,v in itertools.product(range(n+1),repeat=2):
            if dist[u,mid] is not None and dist[mid,v] is not None:
                via=dist[u,mid]+dist[mid,v]
                if dist[u,v] is None or via<dist[u,v]:dist[u,v]=via
    paths={}
    for u,v in itertools.product(range(n+1),repeat=2):
        if u==v:paths[u,v]=(u,);continue
        opts=[];other=[z for z in range(n+1) if z not in (u,v)]
        for size in range(len(other)+1):
            for middle in itertools.permutations(other,size):
                seq=(u,)+middle+(v,);ee=[tuple(sorted((a,b))) for a,b in zip(seq,seq[1:])]
                if all(e in edges for e in ee):opts.append((sum((edges[e] for e in ee),F(0)),len(seq),seq))
        cost,_,path=min(opts);assert cost==dist[u,v];paths[u,v]=path
    def node(v):return {'node':v}
    def normalized(edge,x):
        assert edge in edges and 0<=x<=edges[edge]
        if x==0:return node(edge[0])
        if x==edges[edge]:return node(edge[1])
        return {'edge':list(edge),'x':rat(x)}
    def from_position(s,v):
        if 'node' in s:return dist[s['node'],v]
        u,w=s['edge'];x=f(s['x']);L=edges[u,w];assert 0<x<L
        return min(x+dist[u,v],L-x+dist[w,v])
    def subs(mask):
        s=mask
        while True:
            yield s
            if s==0:break
            s=(s-1)&mask
    def solve(states,need,speeds=None,forced=0):
        speeds=speeds or (F(1),)*len(states);tours={}
        for j,state in enumerate(states):
            for sub in subs(need):
                nodes=[v for v in range(1,n+1) if sub&(1<<(v-1))];choices=[]
                for order in itertools.permutations(nodes):
                    cost=from_position(state,order[0] if order else 0)
                    if order:cost+=sum((dist[u,v] for u,v in zip(order,order[1:]+(0,))),F(0))
                    choices.append((cost/speeds[j],order))
                tours[j,sub]=min(choices)
        @functools.lru_cache(None)
        def dp(left,j):
            if j==len(states):return F(0) if not left else None
            valid=[]
            for sub in subs(left):
                if j>=m and sub&forced:continue
                rest=dp(left^sub,j+1)
                if rest is not None:valid.append(max(rest,tours[j,sub][0]))
            return min(valid) if valid else None
        value=dp(need,0);assert value is not None
        @functools.lru_cache(None)
        def recover(left,j):
            if j==len(states):return () if not left else None
            options=[]
            for sub in subs(left):
                if j>=m and sub&forced:continue
                rest=dp(left^sub,j+1)
                if rest is not None and rest<=value and tours[j,sub][0]<=value:
                    tail=recover(left^sub,j+1)
                    if tail is not None:options.append((tours[j,sub][1],)+tail)
            return min(options) if options else None
        return value,recover(need,0),dp.cache_info().currsize
    def trace(s,order,clock,speed=F(1)):
        out=[]
        def add(edge,x,y,t):
            end=t+abs(y-x)/speed
            if end>t:out.append({'edge':list(edge),'x0':rat(x),'x1':rat(y),'t0':rat(t),'t1':rat(end)})
            return end
        for goal in tuple(order)+(0,):
            if 'node' in s:path=paths[s['node'],goal]
            else:
                u,v=s['edge'];x=f(s['x']);L=edges[u,v]
                _,path=min((x+dist[u,goal],paths[u,goal]),(L-x+dist[v,goal],paths[v,goal]))
                clock=add((u,v),x,F(0) if path[0]==u else L,clock)
            for u,v in zip(path,path[1:]):
                e=tuple(sorted((u,v)));L=edges[e]
                clock=add(e,F(0) if u<v else L,L if u<v else F(0),clock)
            s=node(goal)
        return out
    B,trucks,num=solve([node(0)]*m,full);dpstates+=num
    S,scouts,num=solve([node(0)]*k,full,(alpha,)*k);dpstates+=num
    assert B==f(case['B'])==f(ref['B']) and S==f(case['S'])==f(ref['S'])
    assert trucks==tuple(map(tuple,case['truck_routes'])) and scouts==tuple(map(tuple,case['scout_routes']))
    flights=[trace(node(0),p,F(0),alpha) for p in scouts];reports={}
    sourceflight=[]
    for ll in flights:
        sl=[]
        for p in ll:
            e=tuple(p['edge']);u=e[0] if f(p['x0'])==0 else e[1];v=e[0] if f(p['x1'])==0 else e[1]
            sl.append({'u':u,'v':v,'t0':p['t0'],'t1':p['t1']})
            if v:reports[v]=min(reports.get(v,f(p['t1'])),f(p['t1']))
        sourceflight.append(sl)
    offline=[]
    for w in range(full+1):
        opt,_,num=solve([node(0)]*(m+k),full,(F(1),)*m+(alpha,)*k,w);dpstates+=num;offline.append(opt)
    assert offline==list(map(f,ref['offline']))
    # Family geometry is assessed independently of policy code.
    assert n==4 and m==k==1
    epsilon=f(spec['epsilon']);r0=F(2)/alpha;c0=2-epsilon;T=(2+epsilon)/alpha
    expected_ratio=min(alpha,2+epsilon/2)
    assert alpha>2 and 0<epsilon<2/(alpha+1) and r0<c0<2 and r0<T<c0
    assert max(r0,c0-r0,2*epsilon)<2 and B==4
    assert dist[0,2]==dist[0,3]==c0 and dist[2,3]==2*epsilon and dist[0,4]==r0
    assert c0/alpha>epsilon and (dist[0,2]+dist[2,3])/alpha==T
    geometry_tests=0
    for target in [2,3]:
        for left,right,zL,zR,lo,hi in [(0,1,F(0),r0,F(0),r0),(1,2,r0,c0,r0,T)]:
            lines=[]
            for p,q in itertools.permutations((target,4)):
                tail=dist[p,q]+dist[q,0]
                lines.extend([(1,dist[left,p]-zL+tail,left),(-1,zR+dist[right,p]+tail,right)])
            cuts={lo,hi}
            if lo<c0/alpha<hi:cuts.add(c0/alpha)
            for a,b in itertools.combinations(lines,2):
                if a[0]!=b[0]:
                    x=(b[1]-a[1])/(a[0]-b[0])
                    if lo<x<hi:cuts.add(x)
            cuts=sorted(cuts)
            for x in set(cuts)|{(a+b)/2 for a,b in zip(cuts,cuts[1:])}:
                value=min(a*x+b for a,b,e in lines)
                expected=4-x if target==2 else min(4-x,2*c0+x)
                assert value==expected;geometry_tests+=1
                if lo<x<hi and (target==2 or x>=c0/alpha):assert all(e==right for a,b,e in lines if a*x+b==value)
    assert offline[8]==4/alpha
    slack=f(spec['slack_s']);delay=f(spec['delay']);budget=B+slack
    assert epsilon==(2/(alpha+3) if alpha<=3 else 1/alpha) and 0<=slack<=2*epsilon/alpha
    L=2+epsilon/2-alpha*slack/4
    assert delay==slack
    assert slack<=2/alpha**2 and slack<2*epsilon and slack<=c0/alpha-epsilon
    assert delay<=min(reports.values())
    expected_ratio=min(alpha,L)
    outcomes={};edge_worlds=simultaneous=0;maxcalls=0
    for world,row in enumerate(case['runs']):
        assert row['world']==world and row['policy']=='ordinary_wait_then_exact_reoptimization';total+=1
        states=[node(0)]*m;pending=[trace(node(0),p,delay) for p in trucks];walks=[[] for _ in range(m)]
        seen=served=0;clock=delay;changed_count=0;virtual=False
        if S>B:
            assert row['branch']=='no_launch' and row['events']==[] and row['ground']==pending and row['flight']==[[] for _ in range(k)] and f(row['time'])==B
            outcomes[world]=B;continue
        assert row['branch']=='launched' and row['flight']==sourceflight and f(row['initial_wait'])==delay
        for event_index,event in enumerate(row['events']):
            events_count+=1
            times=[f(p[0]['t1']) for p in pending if p]+[t for v,t in reports.items() if not seen&(1<<(v-1)) and (t>clock or (event_index==0 and t==clock))]
            assert times and f(event['clock'])==min(times) and (min(times)>clock or (event_index==0 and min(times)==clock))
            oldstates=states;clock=min(times);states=[];remaining=[];executed=[];arrived=0;arrivals_count=0
            for j,(s,ll) in enumerate(zip(oldstates,pending)):
                left=[];done=[]
                for p in ll:
                    begin,end=f(p['t0']),f(p['t1']);e=tuple(p['edge']);x,y=f(p['x0']),f(p['x1'])
                    assert e in edges and begin<end and end-begin==abs(y-x)
                    assert normalized(e,x)==s
                    if end<=clock:
                        done.append(p);s=normalized(e,y);assert 'node' in s
                        if s['node']:arrived|=1<<(s['node']-1);arrivals_count+=1
                    elif begin<clock:
                        offset=x+(y-x)*(clock-begin)/(end-begin)
                        done.append(dict(p,x1=rat(offset),t1=rat(clock)));left.append(dict(p,x0=rat(offset),t0=rat(clock)))
                        s=normalized(e,offset)
                        # All later legs are kept byte-for-byte; their starting state is checked on their event.
                        left.extend(ll[len(done):]);break
                    else:
                        left.extend(ll[len(done):]);break
                states.append(s);remaining.append(left);executed.append(done);walks[j].extend(done)
            assert event['states_before_advance']==oldstates and event['states']==states and event['executed']==executed
            assert event['old_plans']==remaining
            reported=sum(1<<(v-1) for v,t in reports.items() if t<=clock)
            changed=bool((reported|arrived)&~seen or arrived&~served);seen|=reported|arrived;served|=arrived
            positive=world&seen;need=full&~served&~(seen&~positive)
            assert (event['arrived'],event['seen'],event['positive'],event['served'],event['need'],event['changed'])==(arrived,seen,positive,served,need,changed)
            oldfinish=max([clock]+[f(p[-1]['t1']) for p in remaining if p]);assert oldfinish==f(event['old_finish'])<=budget
            if changed:
                changed_count+=1;value,routes,num=solve(states,need);dpstates+=num
                assert event['action']=={'value':rat(value),'routes':[list(p) for p in routes]}
                pending=[trace(s,p,clock) for s,p in zip(states,routes)]
                assert clock+value<=oldfinish
                key=(spec['id'],clock,json.dumps(states,sort_keys=True),seen,positive,served)
                action=json.dumps({'routes':routes,'plans':pending},sort_keys=True)
                assert key not in aliases or aliases[key]==action;aliases[key]=action
                virtual|=any('edge' in s for s in states)
                simultaneous+=int(arrivals_count+sum(t==clock for t in reports.values())>1)
                if seen==full:
                    rho=max(from_position(s,0) for s in states);v,_,num=solve([node(0)]*m,need);dpstates+=num
                    assert rho<=clock and value<=rho+v
            else:assert event['action'] is None;pending=remaining
            assert pending==event['new_plans']
            pieces_count+=sum(map(len,executed))
        assert not any(pending) and states==[node(0)]*m and seen==full and world&~served==0 and walks==row['ground']
        mission=max([S]+[f(p['t1']) for ll in walks for p in ll]);assert mission==f(row['time'])<=budget
        bound=3+2*F((m+k-1)//k)/alpha
        outcomes[world]=mission;edge_worlds+=int(virtual);maxcalls=max(maxcalls,changed_count)
    assert len(outcomes)==full+1
    comps={}
    for policy in ['concurrent_backup_portfolio','regretless_fixed_lex_allow_empty','optimistic_fixed_lex']:
        prior={r['world']:f(r['time']) for r in ref['runs'] if r['policy']==policy}
        if not prior:continue
        assert len(prior)==full+1
        comps[policy]={'faster':sum(outcomes[w]<prior[w] for w in outcomes),'equal':sum(outcomes[w]==prior[w] for w in outcomes),'slower':sum(outcomes[w]>prior[w] for w in outcomes)}
    actual=max(outcomes[w]/offline[w] for w in outcomes)
    summaries.append({'slack_s':str(slack),'chosen_wait':str(delay),'family_geometry_tests':geometry_tests,'interior_formula':str(expected_ratio),'interior_formula_match':actual==expected_ratio,'endpoint':slack==2*epsilon/alpha,'endpoint_at_most_two':actual<=2,'launch_equal_report_worlds':sum(bool(row['events']) and f(row['events'][0]['clock'])==delay for row in case['runs']),'id':spec['id'],'worlds':len(outcomes),'all_budget_pass':True,'interior_replan_worlds':edge_worlds,
        'simultaneous_updates':simultaneous,'maximum_replans':maxcalls,'worst_ratio':str(max(outcomes[w]/offline[w] for w in outcomes)),
        'comparisons':comps,'two_OPT_violations':sum(outcomes[w]>2*offline[w] for w in outcomes),'nonredundant_2OPT_worlds':sum(B>2*offline[w] for w in outcomes)})
assert total==result['runs']==160 and len(summaries)==10
assert sum(s['two_OPT_violations'] for s in summaries)==len(result['two_competitive_counterexamples'])
assert sum(s['nonredundant_2OPT_worlds'] for s in summaries)==result['worlds_with_nonredundant_2OPT_check']
with (root/'AUDIT.json').open('x') as fp:json.dump({'state':'independent_floyd_dp_physical_causal_replay_verified','runs':total,
    'events':events_count,'physical_fragments':pieces_count,'subset_dp_states':dpstates,'nonanticipativity_keys':len(aliases),
    'summary':summaries,'general_proof_or_novelty_certified':False},fp,indent=2)
print(json.dumps({'runs':total,'events':events_count,'dp_states':dpstates}))
