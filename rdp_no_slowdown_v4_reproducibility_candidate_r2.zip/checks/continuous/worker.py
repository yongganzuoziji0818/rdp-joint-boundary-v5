import json,time
from fractions import Fraction as F
from pathlib import Path
from model import Experiment,rat
from dynamic import run
root=Path(__file__).resolve().parent;inputs=json.loads((root/'INPUTS.json').read_text());start=time.process_time();cases=[];environments=[]
for spec in inputs['cases']:
    env=Experiment(spec);rows=[run(env,w,F(*spec['delay'])) for w in range(env.full+1)];environments.append(env)
    cases.append({'spec':spec,'B':rat(env.B),'S':rat(env.S),'truck_routes':env.trucks,'scout_routes':env.scouts,'runs':rows})
# Assess only after every policy run; no future demands or OPT are passed to run().
assessment=[];violations=[];nontrivial=0
for case,env in zip(cases,environments):
    offline=[env.fleet(env.full,(F(1),)*env.m+(env.alpha,)*env.k,w)[0] for w in range(env.full+1)]
    assessment.append({'spec':case['spec'],'B':case['B'],'S':case['S'],'offline':list(map(rat,offline)),'runs':[]})
    bound=3+2*F((env.m+env.k-1)//env.k)/env.alpha
    for row in case['runs']:
        t=F(*row['time']);opt=offline[row['world']];assert t<=env.B+F(*case['spec']['slack_s'])
        nontrivial+=int(env.B>2*opt)
        if t>2*opt:violations.append({'id':case['spec']['id'],'world':row['world'],'time':row['time'],'OPT':rat(opt),'B':case['B'],'ratio':str(t/opt)})
out={'state':'optimized_parameter_endpoint_complete_missions' ,'cases':cases,'assessment':assessment,
    'runs':sum(len(c['runs']) for c in cases),'two_competitive_counterexamples':violations,'worlds_with_nonredundant_2OPT_check':nontrivial,
    'cpu_seconds':time.process_time()-start,'general_2competitive_proof_or_novelty_established':False}
assert len(cases)==10 and out['runs']==160
with (root/'RESULT.json').open('x') as fp:json.dump(out,fp,separators=(',',':'))
print(json.dumps({'runs':out['runs'],'2OPT_violations':len(violations),'nonredundant_worlds':nontrivial,'cpu_seconds':out['cpu_seconds']}))
