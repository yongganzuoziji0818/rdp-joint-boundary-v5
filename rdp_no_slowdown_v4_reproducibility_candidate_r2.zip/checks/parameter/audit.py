import json,itertools
from fractions import Fraction as F
from pathlib import Path
root=Path(__file__).resolve().parent
result=json.loads((root/'RESULT.json').read_text());expected=list(itertools.product(
    ['21/10','5/2','3','4','8'],['0','1/2','3/4','99/100']))
assert [(r['alpha'],r['cap_fraction']) for r in result['rows']]==expected
comparisons=0
def zero_cover(points):
    return min(2*(max((F(0),)+p)-min((F(0),)+p)) for p in itertools.product(*points))
def suffix(x,points):
    best=None
    for coords in itertools.product(*points):
        for perm in itertools.permutations(coords):
            seq=(x,)+perm+(F(0),)
            val=sum(abs(t-u) for t,u in zip(seq,seq[1:]))
            best=val if best is None else min(best,val)
    return best
for row in result['rows']:
    a=F(row['alpha']);l=F(row['cap_fraction']);v={k:F(x) for k,x in row['values'].items()}
    # Independent feasible-interval construction, not worker's piecewise epsilon selection.
    cap=min(4/(a*(a+3)),2/a**2);e=cap*a/2;r=2/a;c=2-e;s=l*cap;G=4+s
    assert v['epsilon']==e and v['cap_s']==cap and v['slack']==s
    assert v['new_margin']==min(1/(a*(a+3)),1/(2*a*a))
    assert v['old_margin']==1/(2*a*(a+1))
    points=[[q+4*k for k in range(-2,2)] for q in [c,4-r]]
    cost=zero_cover(points);assert cost>G;comparisons+=16
    tau=c/a;x=tau-s
    points=[[q+4*k for k in range(-2,2)] for q in [4-c,4-r]]
    later=tau+suffix(x,points);assert later>G;comparisons+=32
    assert v['early_gap']==r/a-s>0 and v['late_gap']==(later-G)/2>0
    assert v['loop_gap']==2*(c+r)-G>0
    assert v['positive_v_gap']==2*(4-c)-G>0 and v['travel_gap']==c-(4-c)/a>0
    T=(4-c)/a;return_lower=min(4,T+T-s+2*r)/(2*r)
    assert return_lower==v['lower']>2
    comparisons+=8
assert min(F(r['values']['lower']) for r in result['rows'])>2
# An explicit old-budget point lies strictly below the stronger cap.
a=F(4);s=F(1,10);e=F(1,4)
assert s<F(1,8) and 2+e/2-a*s/4==F(81,40)
out={'state':'independent_finite_arithmetic_and_lift_audit_complete','parameters':20,
     'exact_comparisons':comparisons,'alpha4_old_budget_lower':'81/40',
     'new_missions':0,'general_proof_certified':False,'endpoint_matching_checked':False}
(root/'AUDIT.json').open('x').write(json.dumps(out,indent=2));print(json.dumps(out))
