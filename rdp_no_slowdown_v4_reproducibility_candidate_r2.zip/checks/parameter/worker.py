import json,time
from fractions import Fraction as Q
from pathlib import Path
root=Path(__file__).resolve().parent
start=time.process_time();rows=[]
for item in json.loads((root/'INPUTS.json').read_text())['cases']:
    a=Q(item['alpha']);level=Q(item['cap_fraction'])
    e=2/(a+3) if a<=3 else 1/a
    r=2/a;c=2-e;cap=2*e/a;s=cap*level;G=4+s;eta=2/a**2;T=(2+e)/a
    vals={'epsilon':e,'r':r,'c':c,'cap_s':cap,'slack':s,'eta':eta,'T':T,
          'early_gap':eta-s,'late_gap':c/a-e-s,'loop_gap':2*(c+r)-G,
          'positive_v_gap':2*(2+e)-G,'travel_gap':c-T,
          'lower':min(a,2+e/2-a*s/4),'new_margin':cap/4,
          'old_margin':1/(2*a*(a+1))}
    assert all(vals[k]>0 for k in ['early_gap','late_gap','loop_gap','positive_v_gap','travel_gap'])
    assert vals['lower']>2 and vals['new_margin']>vals['old_margin']
    rows.append(dict(item,values={k:str(v) for k,v in vals.items()}))
assert len(rows)==20
out={'state':'finite_parameter_checks_complete','rows':rows,'new_missions':0,'new_worlds':0,
     'general_proof_certified':False,'worker_cpu_seconds':time.process_time()-start}
(root/'RESULT.json').open('x').write(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k!='rows'}))
