"""Independent Fraction/AST rational identities and witness signs, without SymPy."""
from pathlib import Path
from fractions import Fraction as F
import ast
import json

ROOT = Path(__file__).resolve().parent


def clean(p):
    return {k: v for k, v in p.items() if v}


def plus(p, q):
    result = p.copy()
    for key, value in q.items():
        result[key] = result.get(key, F(0)) + value
    return clean(result)


def times(p, q):
    result = {}
    for (i, j), a in p.items():
        for (k, l), b in q.items():
            key = i+k, j+l
            result[key] = result.get(key, F(0)) + a*b
    return clean(result)


class RF:
    def __init__(self, n, d=None):
        self.n = clean(n) if isinstance(n, dict) else ({(0, 0): F(n)} if n else {})
        self.d = {(0, 0): F(1)} if d is None else clean(d)
        assert self.d

    def __add__(self, b):
        return RF(plus(times(self.n, b.d), times(b.n, self.d)), times(self.d, b.d))

    def __neg__(self):
        return RF({k: -v for k, v in self.n.items()}, self.d)

    def __sub__(self, b):
        return self + (-b)

    def __mul__(self, b):
        return RF(times(self.n, b.n), times(self.d, b.d))

    def __truediv__(self, b):
        assert b.n
        return RF(times(self.n, b.d), times(self.d, b.n))

    def power(self, n):
        assert isinstance(n, int) and n >= 0
        value = RF(1)
        for _ in range(n):
            value = value * self
        return value

    def equals(self, b):
        return times(self.n, b.d) == times(b.n, self.d)


def expression(source, env):
    def visit(node):
        if isinstance(node, ast.Constant):
            assert type(node.value) is int
            return RF(node.value)
        if isinstance(node, ast.Name):
            return env[node.id]
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
            return -visit(node.operand)
        assert isinstance(node, ast.BinOp), ast.dump(node)
        left = visit(node.left)
        if isinstance(node.op, ast.Pow):
            assert isinstance(node.right, ast.Constant)
            return left.power(node.right.value)
        right = visit(node.right)
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        assert isinstance(node.op, ast.Div)
        return left / right
    return visit(ast.parse(source, mode='eval').body)


def from_coeffs(rows):
    result = {}
    for i, j, n, d in rows:
        assert all(type(q) is int for q in [i, j, n, d]) and i >= 0 and j >= 0 and d > 0
        assert (i, j) not in result
        result[i, j] = F(n, d)
    return clean(result)


def has_positive_sign(poly, strict, t_strict):
    if any(q < 0 for q in poly.values()):
        return False
    if not strict:
        return True
    # v can always be zero; t can also be zero in the alpha>=3 branch.
    return any(j == 0 and (t_strict or i == 0) and q > 0 for (i, j), q in poly.items())


def main():
    # Artificial adversarial checks of the checker, not research parameter samples.
    x, y = RF({(1, 0): F(1)}), RF({(0, 1): F(1)})
    one = RF(1)
    assert ((x+one)/(x+one)).equals(one)
    assert not (x+one).equals(x+RF(2))
    assert has_positive_sign({(1, 0): F(1)}, True, True)
    assert not has_positive_sign({(1, 0): F(1)}, True, False)
    assert not has_positive_sign({(0, 1): F(1)}, True, True)
    assert has_positive_sign({}, False, False)
    assert not has_positive_sign({}, True, False)
    assert not has_positive_sign({(0, 0): F(1), (1, 0): F(-1)}, False, False)
    artificial_checks = 8
    spec = json.loads((ROOT/'INPUTS.json').read_text(encoding='utf-8'))
    result = json.loads((ROOT/'CERTIFICATE.json').read_text())
    assert result['state'] == 'all_encoded_rational_obligations_certified'
    expected_keys = [(branch['id'], item['id']) for branch in spec['branches'] for item in spec['obligations']]
    assert [(row['branch'], row['obligation']) for row in result['rows']] == expected_keys
    rows = {(row['branch'], row['obligation']): row for row in result['rows']}
    identities = []
    for branch in spec['branches']:
        assert branch['t_strict'] == (branch['id'] == '2_lt_alpha_lt_3')
        env = {'t': x, 'v': y}
        env['a'] = expression(branch['a'], env)
        for name, src in spec['definitions']:
            env[name] = expression(branch.get('definition_overrides', {}).get(name, src), env)
        for item in spec['obligations']:
            row = rows[branch['id'], item['id']]
            assert row['relation'] == item['relation'] and row['certified']
            witness_n, witness_d = from_coeffs(row['numerator']), from_coeffs(row['denominator'])
            assert has_positive_sign(witness_d, True, False)
            assert has_positive_sign(witness_n, item['relation']=='gt0', branch['t_strict'])
            assert expression(item['expression'], env).equals(RF(witness_n, witness_d)), item['id']
        for item in branch['identities']:
            assert expression(item['expression'], env).equals(RF(0)), item['id']
            identities.append((branch['id'], item['id']))
    for item in spec['general_identities']:
        assert expression(item['expression'], {'a': x, 'e': y}).equals(RF(0))
        identities.append(('general', item['id']))
    assert [(r['branch'], r['id']) for r in result['identities']] == identities
    assert all(r['zero'] for r in result['identities'])
    assert result['sampled_parameter_points'] == 0 and result['new_missions'] == 0
    out = {'state': 'independent_rational_identity_and_sign_audit_complete',
           'verified_inequality_witnesses': len(rows), 'verified_zero_identities': len(identities),
           'artificial_checker_tests': artificial_checks, 'sympy_imported_by_audit': False,
           'all_real_alpha_interval_coverage': '2<alpha<3 via t>0; alpha>=3 via t>=0; slack via v>=0',
           'strict_slack_endpoint_excluded': True, 'alpha3_included': True,
           'sampled_parameter_points': 0, 'new_missions': 0,
           'manual_transcription_and_semantic_policy_arguments_remain_outside_certificate': True,
           'full_theorem_formally_certified': False}
    with (ROOT/'AUDIT.json').open('x') as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out))


if __name__ == '__main__':
    main()
