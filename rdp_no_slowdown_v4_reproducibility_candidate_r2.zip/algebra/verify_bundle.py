"""Byte verification only; does not import worker or auditor."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
items=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
for name,digest in items.items():
    path=(root/name).resolve()
    path.relative_to(root)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==digest,name
print(json.dumps({'state':'hashes_verified','files':len(items),'scientific_execution':False}))
