"""Generate exact rational positivity witnesses, not policy or trajectory samples."""
from pathlib import Path
import json
import time
import sympy as sp

ROOT = Path(__file__).resolve().parent


def coefficients(poly, t, v):
    return [[i, j, int(q.p), int(q.q)] for (i, j), q in
            sorted(sp.Poly(poly, t, v, domain=sp.QQ).terms()) if q != 0]


def positive(coeffs, strict, t_strict):
    if not all(qn >= 0 and qd > 0 for i, j, qn, qd in coeffs):
        return False
    if not strict:
        return True
    return any(qn > 0 and j == 0 and (t_strict or i == 0) for i, j, qn, qd in coeffs)


def main():
    begin = time.process_time()
    spec = json.loads((ROOT/'INPUTS.json').read_text(encoding='utf-8'))
    assert sp.__version__ == spec['sympy_version']
    t, v = sp.symbols('t v')
    rows, identities = [], []
    for branch in spec['branches']:
        env = {'t': t, 'v': v, 'a': sp.sympify(branch['a'], locals={'t': t})}
        for name, expression in spec['definitions']:
            value = branch.get('definition_overrides', {}).get(name, expression)
            env[name] = sp.sympify(value, locals=env)
        for obligation in spec['obligations']:
            value = sp.cancel(sp.sympify(obligation['expression'], locals=env))
            numerator, denominator = sp.fraction(value)
            if denominator.subs({t: 1, v: 1}) < 0:
                numerator, denominator = -numerator, -denominator
            nc, dc = coefficients(numerator, t, v), coefficients(denominator, t, v)
            denominator_ok = positive(dc, True, False)
            numerator_ok = positive(nc, obligation['relation'] == 'gt0', branch['t_strict'])
            row = {'branch': branch['id'], 'obligation': obligation['id'],
                   'relation': obligation['relation'], 'numerator': nc, 'denominator': dc,
                   'certified': denominator_ok and numerator_ok}
            rows.append(row)
            if not row['certified']:
                with (ROOT/'CERTIFICATE_PARTIAL.json').open('x') as f:
                    json.dump({'state': 'not_certified_stop', 'rows': rows}, f, indent=2)
                raise AssertionError((branch['id'], obligation['id'], value))
        for item in branch['identities']:
            value = sp.cancel(sp.sympify(item['expression'], locals=env))
            assert value == 0, (branch['id'], item['id'], value)
            identities.append({'branch': branch['id'], 'id': item['id'], 'zero': True})
    a, e = sp.symbols('a e')
    for item in spec['general_identities']:
        assert sp.cancel(sp.sympify(item['expression'], locals={'a': a, 'e': e})) == 0
        identities.append({'branch': 'general', 'id': item['id'], 'zero': True})
    out = {'state': 'all_encoded_rational_obligations_certified', 'sympy_version': sp.__version__,
           'rows': rows, 'identities': identities, 'rational_inequality_witnesses': len(rows),
           'rational_identity_witnesses': len(identities), 'sampled_parameter_points': 0,
           'new_missions': 0, 'cpu_seconds': time.process_time()-begin,
           'policy_causality_geometry_and_full_theorem_formalized': False}
    with (ROOT/'CERTIFICATE.json').open('x') as f:
        json.dump(out, f, indent=2)
    print(json.dumps({k: value for k, value in out.items() if k not in ['rows', 'identities']}))


if __name__ == '__main__':
    main()
