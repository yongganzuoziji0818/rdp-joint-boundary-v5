# Exact rational parameter certificates: local reader addendum

This addendum concerns only the encoded rational inequalities used in contribution
version RDP_JOINT_OPTIMALITY_V4_20261023. It is not a publication, license grant or
formalization of the whole policy theorem.

Extract to a fresh directory. With Python 3.10+ and the standard library, run:

    python -B verify_bundle.py
    python -B audit.py

The first command checks eight file hashes and executes no mathematical audit.
The second independently checks 58 inequality witnesses and nine zero identities
with Fraction polynomial arithmetic; it does not import SymPy, sample parameters
or execute trajectories. It writes a new AUDIT.json and refuses to overwrite an
existing one. Its output should equal REFERENCE_AUDIT.json. Use a fresh directory
for another run, preserving previous outputs.

To regenerate witnesses, use a separate fresh directory containing worker.py and
INPUTS.json, and an existing SymPy 1.14.0 environment, then run python -B worker.py.
Do not overwrite the retained certificate. The observed execution was on Linux
Python 3.12.3; the standard-library reader has not been executed on other platforms.

INPUTS.json encodes alpha=(2+3t)/(1+t), t>0, for 2<alpha<3, and alpha=3+t,
t>=0, for alpha>=3. In both branches s=s_star*v/(1+v), v>=0. This covers the
strict budget interval, not s=s_star. Nonnegative coefficient witnesses plus a
strictly positive denominator prove the stated encoded inequalities. The audit
checks polynomial cross-identities using a separate implementation.

SOURCE_lower_bound.tex is the exact working source to which this transcription
was tied; correspondence between prose, causal policy arguments and the input
list remains a manual mathematical responsibility. Several obligations are
algebraically dependent; 58 is not a count of independent findings or samples.
No universal policy proof, novelty, general-network tightness, experimental
performance gain or target-journal qualification is certified. This addendum
does not alter the separately retained four-batch simulation package.
