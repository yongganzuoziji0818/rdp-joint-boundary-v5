"""Replay four frozen finite checks with Python 3.10+ and its standard library."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
IGNORED = {('parameter', 'RESULT.json'): 'worker_cpu_seconds',
           ('continuous', 'RESULT.json'): 'cpu_seconds',
           ('balanced', 'MISSION_RESULT.json'): 'cpu_seconds',
           ('bottleneck', 'MISSION_RESULT.json'): 'cpu_seconds'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def canonical(value, label, name):
    value = dict(value)
    key = IGNORED.get((label, name))
    if key is not None:
        assert key in value and isinstance(value[key], (int, float)), (label, name, key)
        del value[key]
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    options = parser.add_mutually_exclusive_group(required=True)
    options.add_argument('--verify-only', action='store_true')
    options.add_argument('--out', type=Path)
    args = parser.parse_args()
    assert sys.version_info >= (3, 10), 'Python 3.10 or later is required'
    manifest = read(ROOT / 'MANIFEST.json')
    for name, expected in manifest.items():
        path = (ROOT / name).resolve()
        path.relative_to(ROOT)
        assert sha(path) == expected, name
    if args.verify_only:
        print(json.dumps({'state': 'packet_hashes_verified_no_scientific_execution',
                          'files': len(manifest), 'mission_executions': 0}))
        return
    output = args.out.resolve()
    assert output != ROOT and output not in ROOT.parents
    output.mkdir(parents=True, exist_ok=False)
    environment = os.environ.copy()
    for key in ['PYTHONPATH', 'PYTHONHOME', 'LD_PRELOAD']:
        environment.pop(key, None)
    environment.update(PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0', PYTHONUTF8='1',
                       PYTHONNOUSERSITE='1', CUDA_VISIBLE_DEVICES='', OMP_NUM_THREADS='1',
                       OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
    begin = time.monotonic()
    rows = []
    for spec in read(ROOT / 'PROVENANCE.json')['checks']:
        label = spec['id']
        job = output / label
        job.mkdir()
        for name in spec['code']:
            shutil.copyfile(ROOT / 'checks' / label / name, job / name)
            assert sha(job / name) == manifest['checks/' + label + '/' + name]
        times = {}
        for script in ['worker.py', 'audit.py']:
            start = time.monotonic()
            process = subprocess.run([sys.executable, '-B', script], cwd=job, env=environment,
                                     capture_output=True, timeout=30, check=False)
            (job / (script + '.stdout')).write_bytes(process.stdout)
            (job / (script + '.stderr')).write_bytes(process.stderr)
            assert process.returncode == 0, (label, script, process.stderr.decode(errors='replace'))
            times[script] = time.monotonic() - start
        comparisons = []
        for name in spec['outputs']:
            actual = canonical(read(job / name), label, name)
            reference = canonical(read(ROOT / 'reference' / label / name), label, name)
            assert actual == reference, (label, name)
            key = IGNORED.get((label, name))
            comparisons.append({'file': name, 'canonical_sha256': hashlib.sha256(actual.encode()).hexdigest(),
                                'ignored_top_level_fields': [key] if key else []})
        rows.append({'id': label, 'comparisons': comparisons,
                     'existing_missions': spec['existing_missions'],
                     'parameter_points': spec.get('parameter_points', 0),
                     'stage_wall_seconds': times})
    result = {'state': 'four_existing_finite_batches_reproduced_exactly', 'checks': rows,
              'reexecuted_existing_missions': sum(s['existing_missions'] for s in rows),
              'parameter_points': 20, 'parameter_exact_comparisons': 1120,
              'derived_fixed_world_expectations': 80,
              'new_unique_scientific_missions': 0, 'independent_statistical_replicates_added': 0,
              'wall_seconds': time.monotonic() - begin,
              'universal_proof_or_novelty_certified': False, 'public_release_authorized': False}
    assert result['reexecuted_existing_missions'] == 240
    assert sum(len(s['comparisons']) for s in rows) == 12
    with (output / 'REPRODUCTION.json').open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result))


if __name__ == '__main__':
    main()
