# Companion reproducibility artifact: local release candidate

Companion manuscript: **The cost of a no-slowdown guarantee in online relief distribution with a truck and a drone**.
Research contribution version: RDP_JOINT_OPTIMALITY_V4_20261023.

This is a locally prepared candidate, not a published repository record. No DOI,
redistribution license or public-release authorization has been assigned to this new work.
The earlier marginal-recurrence paper and its repository are different works.

## What this artifact contains

The unchanged `portable_exact_checks_v2` engine, its frozen constructed inputs and
reference results cover four finite checks: 20 parameter points / 1,120 exact
comparisons; 160 continuous-motion tasks; and 80 tasks under an explicit original-edge
commitment contract. There are 240 existing task executions in total. The 80 expected
values are derived from those node-contract tasks, not extra executions or statistical
replicates. These are deliberately constructed mathematical cases, not field missions,
an independently sampled disaster dataset, or tests of every causal online policy.

The implementation is the small project implementation identified in the frozen
source headers; it is not a reproduction of source code supplied by the authors of
the original RDP paper. The task definition is attributed to Neugebauer, Otto and
Schmidt, *The relief distribution problem with trucks and drones under incomplete
demand information*, arXiv:2603.23135v1: https://arxiv.org/abs/2603.23135v1 .
No third-party paper PDFs, downloaded images or private server credentials are included.

## Exact-algebra addendum

The `algebra/` directory retains all nine members of the separately audited rational
certificate packet unchanged. It supplies 58 branch-specific inequality witnesses
(29 obligations times two speed branches), nine zero identities and eight artificial
adversarial checker cases. The substitutions cover all speed ratios greater than two
and all nonnegative budgets strictly below the constructed threshold. These are
encoded algebraic statements, not 58 independent findings, new task executions or
independently sampled parameter values. The source snapshot accompanying the packet
predates the current exposition revision and is retained unchanged for traceability.

From `algebra/`, run the hash-only check:

```sh
python -B verify_bundle.py
```

Then, in a fresh extraction, the standard-library mathematical checker can be run:

```sh
python -B audit.py
```

It reads the supplied certificate and writes a new `AUDIT.json`; `REFERENCE_AUDIT.json`
is retained separately. This does not simulate a task. The auditor uses exact Fraction
arithmetic and polynomial cross-multiplication and does not import SymPy. Optional
regeneration of the certificate requires SymPy 1.14.0 and a separate fresh directory;
follow `algebra/README.md`. The optional generator is the only non-standard-library
program in this artifact. No dependency installation occurs during normal reader checks.

The audit does not formally verify source transcription, causal histories, closed-walk
arguments, physical realizability, universal policy quantification or research novelty.
Those remain mathematical and scholarly obligations in the manuscript. Its artificial
adversarial cases test checker logic, not additional scientific instances.

## Requirements and commands

Python 3.10 or later and its standard library; no package installation, network,
GPU, training or account access is needed. Extract the ZIP into a fresh directory.
From that directory, first run the byte-integrity check (no scientific tasks):

```sh
python -B reproduce.py --verify-only
```

To reproduce the existing four finite batches, choose an output directory that
does not exist yet:

```sh
python -B reproduce.py --out ./fresh_results
```

The second command executes the frozen workers and computational audits and
compares all twelve scientific JSON outputs with their references. Each internal
worker/audit entry point has a 30-second wall-clock timeout. Reference execution
was on a Linux CPU; other platforms have not been certified by this release preparation.
An input, byte or scientific-value mismatch stops execution. The launcher refuses
an existing output directory; do not delete evidence or tune inputs to make it pass.

Only these four **top-level** reference timing fields are excluded from JSON equality:

| Output | Excluded timing field |
|---|---|
| `parameter/RESULT.json` | `worker_cpu_seconds` |
| `continuous/RESULT.json` | `cpu_seconds` |
| `balanced/MISSION_RESULT.json` | `cpu_seconds` |
| `bottleneck/MISSION_RESULT.json` | `cpu_seconds` |

All other scientific values, complete trajectories, observation/service/depot-return
completion, rational optima, adverse outcomes and audit counts remain compared.

## File map and integrity

- `checks/`: 24 unchanged science code/input files; each batch has `worker.py`, `audit.py` and `INPUTS.json`.
- `reference/`: twelve unchanged scientific JSON reference outputs.
- `reproduce.py`: unchanged verification/replay entry point.
- `PROVENANCE.json`: original batch identities and manifest hashes.
- `MANIFEST.json`: unchanged engine manifest for 39 original members; it does not hash itself.
- `algebra/`: nine unchanged certificate-reader members with their own eight-entry manifest.
- `PRIOR_REMOTE_REPLAY_AUDIT.json`: unchanged summary from the already completed four-batch CPU replay.
- `ARTIFACT_INDEX.json`: hashes and sizes for all candidate payload files other than the index/checksum list themselves.
- `CHECKSUMS.sha256`: hashes for all other payload files, including `ARTIFACT_INDEX.json`; it does not hash itself.
- `README.md`: retained engine-v2 preparation notes; this file explains the V4 companion scope.

The prior replay audit is a computational check separate from the worker
implementation; it is not independent human review. Preparing this release candidate
did not re-execute the tasks. A replay adds no new independent scientific samples,
and finite agreement does not prove the universal theorems, novelty, general-network
sufficiency, disaster-response gains or the added analytic corollary's universal scope.

Authors, contribution roles and funding were confirmed for this manuscript; the
separate local metadata draft records those facts. Ownership and redistribution
license, final review of the current revision, repository metadata and publication
permission must still be settled before public release.
No previous manuscript's DOI should be used as this artifact's persistent identifier.
