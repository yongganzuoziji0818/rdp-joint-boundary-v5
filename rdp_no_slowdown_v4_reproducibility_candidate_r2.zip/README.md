# Finite relief-distribution checks: portable packet v2

Python 3.10 or later; standard library only. No installation, network access, GPU or training is required.

Extract to a fresh directory. From its root:

    python -B reproduce.py --verify-only
    python -B reproduce.py --out "./fresh output"

The first command verifies file hashes without executing scientific tasks. The second refuses to reuse an existing output directory and runs the original frozen worker and audit scripts for four batches. It compares twelve scientific JSON outputs with their references. Each internal script has a 30-second timeout; this is a small finite construction check, not a large benchmark.

The package includes twenty parameter points (1,120 exact comparisons), 160 continuous-motion task executions and 80 node-contract task executions. Replaying them adds no new statistical replicates. The 80 fixed-world expected values are derived from those node executions and are not additional tasks.

Only the following top-level timing fields are excluded from exact JSON comparison:

- `reference/parameter/RESULT.json`: `worker_cpu_seconds`;
- `reference/continuous/RESULT.json`: `cpu_seconds`;
- `reference/balanced/MISSION_RESULT.json`: `cpu_seconds`;
- `reference/bottleneck/MISSION_RESULT.json`: `cpu_seconds`.

All trajectories, observations, actions, complete-task times, budgets, exact informed optima, arithmetic values, audit counts and adverse outcomes are compared. `PROVENANCE.json` lists the original batch identities and hashes. `MANIFEST.json` binds the copied code, inputs, references and entry point. A mismatch stops the run; thresholds and inputs are not changed to make a replay pass.

These finite checks do not enumerate all online policies, prove the universal theorems, establish novelty, demonstrate operational disaster benefits, or numerically validate every additional analytic corollary. No statistical significance, runtime improvement or method superiority is inferred from a replay.

This is a private preparation copy. A redistribution license and public persistent identifier have not yet been assigned. No previous paper's archive is presented as the archive of this new study.
